// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// ilimo's `subscriber_slots`: the server answers each receive section with the msid stream id
// `ilimo_slot` and says which remote track each one carries in a SlotUpdate, carried encoded in
// SignalResponse field 100 (`bytes ilimo`, an ilimo.signal.IlimoResponse). See
// proto/ilimo/signal_ext.proto and docs/specs/protocol-extensions.md in the ilimo repo.
import { BinaryReader, type Message, WireType } from '@bufbuild/protobuf';

/** The msid stream id of every slot section. */
export const SLOT_STREAM_ID = 'ilimo_slot';

export interface IlimoSlot {
  /** The slot's receive section. */
  mid: string;
  /** Empty when the slot carries nothing. */
  participantSid: string;
  trackSid: string;
  /** RTP timestamp of the first packet of this track on the slot. */
  rtpTimestamp: number;
}

const ILIMO_FIELD = 100;
const SLOT_UPDATE_FIELD = 1;
const SLOTS_FIELD = 1;

/** The slots of the SlotUpdate `response` carries, if any. */
export function readSlotUpdate(response: Message): IlimoSlot[] | undefined {
  try {
    const ilimo = lengthDelimited(response.toBinary(), ILIMO_FIELD);
    const update = ilimo && lengthDelimited(ilimo, SLOT_UPDATE_FIELD);
    return update && decodeSlots(update);
  } catch {
    return undefined;
  }
}

function lengthDelimited(bytes: Uint8Array, field: number): Uint8Array | undefined {
  const reader = new BinaryReader(bytes);
  while (reader.pos < bytes.length) {
    const [fieldNo, wireType] = reader.tag();
    if (fieldNo === field && wireType === WireType.LengthDelimited) {
      return reader.bytes();
    }
    reader.skip(wireType, fieldNo);
  }
  return undefined;
}

function decodeSlots(bytes: Uint8Array): IlimoSlot[] {
  const slots: IlimoSlot[] = [];
  const reader = new BinaryReader(bytes);
  while (reader.pos < bytes.length) {
    const [fieldNo, wireType] = reader.tag();
    if (fieldNo === SLOTS_FIELD && wireType === WireType.LengthDelimited) {
      slots.push(decodeSlot(reader.bytes()));
    } else {
      reader.skip(wireType, fieldNo);
    }
  }
  return slots;
}

function decodeSlot(bytes: Uint8Array): IlimoSlot {
  const slot: IlimoSlot = { mid: '', participantSid: '', trackSid: '', rtpTimestamp: 0 };
  const reader = new BinaryReader(bytes);
  while (reader.pos < bytes.length) {
    const [fieldNo, wireType] = reader.tag();
    if (fieldNo === 1 && wireType === WireType.LengthDelimited) {
      slot.mid = reader.string();
    } else if (fieldNo === 2 && wireType === WireType.LengthDelimited) {
      slot.participantSid = reader.string();
    } else if (fieldNo === 3 && wireType === WireType.LengthDelimited) {
      slot.trackSid = reader.string();
    } else if (fieldNo === 4 && wireType === WireType.Varint) {
      slot.rtpTimestamp = reader.uint32();
    } else {
      reader.skip(wireType, fieldNo);
    }
  }
  return slot;
}
