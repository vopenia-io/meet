// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// SignalFrame is the wire-level envelope ilimo's `_signal` data channel uses to carry signaling
// protobufs (see proto/ilimo/signal_dc.proto in the ilimo repo: `message SignalFrame { uint64 seq
// = 1; bytes payload = 2; }`). Two scalar fields — hand-encoding with BinaryWriter/BinaryReader
// avoids adding a protoc/buf generation step to this SDK for one small envelope shared by no other
// message.
import { BinaryReader, BinaryWriter, WireType } from '@bufbuild/protobuf';

/** ilimo's client-created signaling data channel — see crates/ilimo-rtc/src/channels.rs in the ilimo repo. */
export const SIGNAL_DATA_CHANNEL_LABEL = '_signal';

const SEQ_FIELD = 1;
const PAYLOAD_FIELD = 2;

export function encodeSignalFrame(seq: number, payload: Uint8Array): Uint8Array {
  const writer = new BinaryWriter();
  writer.tag(SEQ_FIELD, WireType.Varint).uint64(seq);
  writer.tag(PAYLOAD_FIELD, WireType.LengthDelimited).bytes(payload);
  return writer.finish();
}

/** Returns the frame's payload, or `undefined` if `bytes` isn't a well-formed SignalFrame. */
export function decodeSignalFramePayload(bytes: Uint8Array): Uint8Array | undefined {
  const reader = new BinaryReader(bytes);
  let payload: Uint8Array | undefined;
  try {
    while (reader.pos < bytes.length) {
      const [fieldNo, wireType] = reader.tag();
      if (fieldNo === SEQ_FIELD && wireType === WireType.Varint) {
        reader.uint64();
      } else if (fieldNo === PAYLOAD_FIELD && wireType === WireType.LengthDelimited) {
        payload = reader.bytes();
      } else {
        reader.skip(wireType, fieldNo);
      }
    }
  } catch {
    return undefined;
  }
  return payload;
}
