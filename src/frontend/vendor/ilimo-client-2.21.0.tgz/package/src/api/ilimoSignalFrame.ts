// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// SignalFrame is the wire-level envelope ilimo's `_signal` data channel uses to carry signaling
// protobufs (see proto/ilimo/signal_dc.proto in the ilimo repo: `message SignalFrame { uint64 seq
// = 1; bytes payload = 2; uint64 ack = 3; bool more = 4; }`). A few scalar fields — hand-encoding
// with BinaryWriter/BinaryReader avoids adding a protoc/buf generation step to this SDK for one
// small envelope shared by no other message.
import { BinaryReader, BinaryWriter, WireType } from '@bufbuild/protobuf';

/** ilimo's client-created signaling data channel — see crates/ilimo-rtc/src/channels.rs in the ilimo repo. */
export const SIGNAL_DATA_CHANNEL_LABEL = '_signal';

const SEQ_FIELD = 1;
const PAYLOAD_FIELD = 2;
const ACK_FIELD = 3;
const MORE_FIELD = 4;

export interface SignalFrame {
  /** 0 for an acknowledgment alone. */
  seq: number;
  payload: Uint8Array;
  /** `signal_continuity`: every frame of the other direction up to this seq was received. */
  ack?: number;
  /** `signal_continuity`: the message goes on in the next frame. */
  more?: boolean;
}

export function encodeSignalFrame(frame: SignalFrame): Uint8Array {
  const writer = new BinaryWriter();
  writer.tag(SEQ_FIELD, WireType.Varint).uint64(frame.seq);
  writer.tag(PAYLOAD_FIELD, WireType.LengthDelimited).bytes(frame.payload);
  if (frame.ack) {
    writer.tag(ACK_FIELD, WireType.Varint).uint64(frame.ack);
  }
  if (frame.more) {
    writer.tag(MORE_FIELD, WireType.Varint).bool(true);
  }
  return writer.finish();
}

/** Returns the frame, or `undefined` if `bytes` isn't a well-formed SignalFrame. */
export function decodeSignalFrame(bytes: Uint8Array): SignalFrame | undefined {
  const reader = new BinaryReader(bytes);
  const frame: SignalFrame = { seq: 0, payload: new Uint8Array() };
  try {
    while (reader.pos < bytes.length) {
      const [fieldNo, wireType] = reader.tag();
      if (fieldNo === SEQ_FIELD && wireType === WireType.Varint) {
        frame.seq = Number(reader.uint64());
      } else if (fieldNo === PAYLOAD_FIELD && wireType === WireType.LengthDelimited) {
        frame.payload = reader.bytes();
      } else if (fieldNo === ACK_FIELD && wireType === WireType.Varint) {
        frame.ack = Number(reader.uint64());
      } else if (fieldNo === MORE_FIELD && wireType === WireType.Varint) {
        frame.more = reader.bool();
      } else {
        reader.skip(wireType, fieldNo);
      }
    }
  } catch {
    return undefined;
  }
  return frame;
}
