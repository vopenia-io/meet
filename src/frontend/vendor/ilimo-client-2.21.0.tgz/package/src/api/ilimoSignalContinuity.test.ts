// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
import { SignalRequest, SignalResponse } from '@livekit/protocol';
import { describe, expect, it } from 'vitest';
import {
  FRAGMENT_BYTES,
  SignalInbox,
  SignalOutbox,
  encodeIlimoRequestFrame,
  readIlimoSignalFrame,
} from './ilimoSignalContinuity';
import { encodeSignalFrame } from './ilimoSignalFrame';
import { lengthDelimited } from './ilimoSlots';

describe('ilimoSignalContinuity', () => {
  it('sends a long message in fragments that come back whole', () => {
    const message = new Uint8Array(FRAGMENT_BYTES * 2 + 5).map((_, i) => i % 251);
    const frames = new SignalOutbox(true).push(message);
    expect(frames.map((frame) => [frame.seq, frame.more])).toEqual([
      [1, true],
      [2, true],
      [3, false],
    ]);
    const inbox = new SignalInbox(true);
    const whole = frames.map((frame) => inbox.receive(frame)).filter((m) => m !== undefined);
    expect(whole).toEqual([message]);
    expect(inbox.received).toBe(3);
  });

  it('keeps the frames until acknowledged', () => {
    const outbox = new SignalOutbox(true);
    for (const byte of [1, 2, 3]) {
      outbox.push(new Uint8Array([byte]));
    }
    outbox.acknowledge(2);
    expect(outbox.replay().map((frame) => frame.seq)).toEqual([3]);
    expect(outbox.lost).toBe(false);
  });

  it('keeps nothing and never fragments without signal_continuity', () => {
    const outbox = new SignalOutbox(false);
    expect(outbox.push(new Uint8Array(FRAGMENT_BYTES * 2))).toHaveLength(1);
    expect(outbox.replay()).toEqual([]);
  });

  it('drops duplicates and refuses a gap', () => {
    const inbox = new SignalInbox(true);
    const frame = (seq: number) => ({ seq, payload: new Uint8Array([seq]) });
    expect(inbox.receive(frame(1))).toEqual(new Uint8Array([1]));
    expect(inbox.receive(frame(1))).toBeUndefined();
    expect(() => inbox.receive(frame(3))).toThrow('frames missing');
    expect(inbox.receive(inbox.ackFrame())).toBeUndefined();
    expect(inbox.received).toBe(1);
    expect(inbox.ackDue).toBe(true);
  });

  it('reads a frame replayed in a WebSocket response, and wraps one in a request', () => {
    const frame = { seq: 4, payload: new Uint8Array([9]), ack: 2 };
    const ilimo = new Uint8Array([0x12, ...withLength(encodeSignalFrame(frame))]);
    const response = SignalResponse.fromBinary(new Uint8Array([0xa2, 0x06, ...withLength(ilimo)]));
    expect(readIlimoSignalFrame(response)).toEqual(frame);

    const request = encodeIlimoRequestFrame(frame);
    const ilimoRequest = lengthDelimited(request, 100);
    expect(ilimoRequest && lengthDelimited(ilimoRequest, 1)).toEqual(encodeSignalFrame(frame));
    expect(SignalRequest.fromBinary(request).message.case).toBeUndefined();
  });
});

function withLength(bytes: Uint8Array): number[] {
  return [bytes.length, ...bytes];
}
