// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
import { describe, expect, it } from 'vitest';
import { decodeSignalFramePayload, encodeSignalFrame } from './ilimoSignalFrame';

describe('ilimoSignalFrame', () => {
  it('round-trips a payload', () => {
    const payload = new Uint8Array([1, 2, 3, 255, 0]);
    const frame = encodeSignalFrame(42, payload);
    expect(decodeSignalFramePayload(frame)).toEqual(payload);
  });

  it('round-trips an empty payload', () => {
    const frame = encodeSignalFrame(1, new Uint8Array());
    expect(decodeSignalFramePayload(frame)).toEqual(new Uint8Array());
  });

  it('returns undefined for garbage bytes', () => {
    const garbage = new Uint8Array([0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff]);
    expect(decodeSignalFramePayload(garbage)).toBeUndefined();
  });
});
