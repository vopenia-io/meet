// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
import { describe, expect, it } from 'vitest';
import { decodeSignalFrame, encodeSignalFrame } from './ilimoSignalFrame';

describe('ilimoSignalFrame', () => {
  it('round-trips a frame', () => {
    const frame = { seq: 42, payload: new Uint8Array([1, 2, 3, 255, 0]), ack: 7, more: true };
    expect(decodeSignalFrame(encodeSignalFrame(frame))).toEqual(frame);
  });

  it('round-trips an acknowledgment alone', () => {
    const frame = { seq: 0, payload: new Uint8Array(), ack: 3 };
    expect(decodeSignalFrame(encodeSignalFrame(frame))).toEqual(frame);
  });

  it('returns undefined for garbage bytes', () => {
    const garbage = new Uint8Array([0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff]);
    expect(decodeSignalFrame(garbage)).toBeUndefined();
  });
});
