import { BinaryWriter, WireType } from '@bufbuild/protobuf';
import {
  ClientInfo_Capability,
  DisconnectReason,
  JoinRequest,
  JoinResponse,
  LeaveRequest,
  ReconnectResponse,
  ServerInfo,
  SignalRequest,
  SignalResponse,
  TrackPublishedResponse,
  WrappedJoinRequest,
  WrappedJoinRequest_Compression,
} from '@livekit/protocol';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ConnectionError, ConnectionErrorReason } from '../room/errors';
import { SignalClient, SignalConnectionState, WEBSOCKET_DRAIN_MS } from './SignalClient';
import type { WebSocketCloseInfo, WebSocketConnection } from './WebSocketStream';
import { WebSocketStream } from './WebSocketStream';
import {
  SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
  SUBSCRIBER_SLOTS_CAPABILITY,
  readIlimoCapabilities,
  withIlimoCapabilities,
} from './ilimoCapabilities';
import { decodeSignalFramePayload, encodeSignalFrame } from './ilimoSignalFrame';

// Mock the WebSocketStream
vi.mock('./WebSocketStream');

// Mock fetch for validation endpoint
global.fetch = vi.fn();

// Test Helpers
function createJoinResponse() {
  return new JoinResponse({
    room: { name: 'test-room', sid: 'room-sid' },
    participant: { sid: 'participant-sid', identity: 'test-user' },
    pingTimeout: 30,
    pingInterval: 10,
  });
}

function createSignalResponse(
  messageCase: 'join' | 'reconnect' | 'leave' | 'update',
  value: any,
): SignalResponse {
  return new SignalResponse({
    message: { case: messageCase, value },
  });
}

function createMockReadableStream(responses: SignalResponse[]): ReadableStream<ArrayBuffer> {
  return new ReadableStream<ArrayBuffer>({
    async start(controller) {
      for (const response of responses) {
        controller.enqueue(response.toBinary().buffer as ArrayBuffer);
      }
    },
  });
}

function createMockConnection(readable: ReadableStream<ArrayBuffer>): WebSocketConnection {
  return {
    readable,
    writable: new WritableStream(),
    protocol: '',
    extensions: '',
  };
}

interface MockWebSocketStreamOptions {
  connection?: WebSocketConnection;
  opened?: Promise<WebSocketConnection>;
  closed?: Promise<WebSocketCloseInfo>;
  onUrl?: (url: string) => void;
  readyState?: number;
}

function mockWebSocketStream(options: MockWebSocketStreamOptions = {}) {
  const {
    connection,
    opened = connection ? Promise.resolve(connection) : new Promise(() => {}),
    closed = new Promise(() => {}),
    readyState = 1,
    onUrl,
  } = options;

  return vi.mocked(WebSocketStream).mockImplementationOnce(function (url) {
    onUrl?.(url);
    return {
      url: 'wss://test.livekit.io',
      opened,
      closed,
      close: vi.fn(),
      readyState,
    } as any;
  });
}

describe('SignalClient.connect', () => {
  let signalClient: SignalClient;

  const defaultOptions = {
    autoSubscribe: true,
    maxRetries: 0,
    e2eeEnabled: false,
    websocketTimeout: 1000,
    singlePeerConnection: false,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    signalClient = new SignalClient(false);
  });

  async function decodeJoinRequestFromUrl(url: string): Promise<JoinRequest> {
    const joinRequestParam = new URL(url).searchParams.get('join_request');
    expect(joinRequestParam).toBeTruthy();

    const paddedBase64Url = joinRequestParam!.padEnd(
      joinRequestParam!.length + ((4 - (joinRequestParam!.length % 4)) % 4),
      '=',
    );
    const binaryString = atob(paddedBase64Url.replace(/-/g, '+').replace(/_/g, '/'));
    const wrappedBytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i += 1) {
      wrappedBytes[i] = binaryString.charCodeAt(i);
    }

    const wrappedJoinRequest = WrappedJoinRequest.fromBinary(wrappedBytes);
    if (wrappedJoinRequest.compression === WrappedJoinRequest_Compression.NONE) {
      return JoinRequest.fromBinary(wrappedJoinRequest.joinRequest);
    }

    const stream = new DecompressionStream('gzip');
    const writer = stream.writable.getWriter();
    writer.write(wrappedJoinRequest.joinRequest);
    writer.close();

    const chunks: Uint8Array[] = [];
    const reader = stream.readable.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
    }
    const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
    const bytes = new Uint8Array(totalLength);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.length;
    }
    return JoinRequest.fromBinary(bytes);
  }

  describe('Happy Path - Initial Join', () => {
    it('should successfully connect and receive join response', async () => {
      const joinResponse = createJoinResponse();
      const signalResponse = createSignalResponse('join', joinResponse);
      const mockReadable = createMockReadableStream([signalResponse]);
      const mockConnection = createMockConnection(mockReadable);

      mockWebSocketStream({ connection: mockConnection });

      const result = await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

      expect(result).toEqual(joinResponse);
      expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
    });

    it('does not advertise packet trailer capability by default', async () => {
      const joinResponse = createJoinResponse();
      const signalResponse = createSignalResponse('join', joinResponse);
      const mockReadable = createMockReadableStream([signalResponse]);
      const mockConnection = createMockConnection(mockReadable);
      let capturedUrl = '';

      mockWebSocketStream({
        connection: mockConnection,
        onUrl: (url) => {
          capturedUrl = url;
        },
      });

      await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

      const joinRequest = await decodeJoinRequestFromUrl(capturedUrl);
      expect(joinRequest.clientInfo?.capabilities).toEqual([]);
    });

    it('advertises packet trailer capability when provided', async () => {
      const joinResponse = createJoinResponse();
      const signalResponse = createSignalResponse('join', joinResponse);
      const mockReadable = createMockReadableStream([signalResponse]);
      const mockConnection = createMockConnection(mockReadable);
      let capturedUrl = '';

      mockWebSocketStream({
        connection: mockConnection,
        onUrl: (url) => {
          capturedUrl = url;
        },
      });

      await signalClient.join('wss://test.livekit.io', 'test-token', {
        ...defaultOptions,
        clientInfoCapabilities: [ClientInfo_Capability.CAP_PACKET_TRAILER],
      });

      const joinRequest = await decodeJoinRequestFromUrl(capturedUrl);
      expect(joinRequest.clientInfo?.capabilities).toEqual([
        ClientInfo_Capability.CAP_PACKET_TRAILER,
      ]);
    });
  });

  describe('Happy Path - Reconnect', () => {
    it('should successfully reconnect and receive reconnect response', async () => {
      // First, set up initial connection
      const joinResponse = createJoinResponse();
      const joinSignalResponse = createSignalResponse('join', joinResponse);
      const initialMockReadable = createMockReadableStream([joinSignalResponse]);
      const initialMockConnection = createMockConnection(initialMockReadable);

      mockWebSocketStream({ connection: initialMockConnection });

      await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

      // Now test reconnect
      const reconnectResponse = new ReconnectResponse({
        iceServers: [],
      });
      const reconnectSignalResponse = createSignalResponse('reconnect', reconnectResponse);
      const reconnectMockReadable = createMockReadableStream([reconnectSignalResponse]);
      const reconnectMockConnection = createMockConnection(reconnectMockReadable);

      mockWebSocketStream({ connection: reconnectMockConnection });

      const result = await signalClient.reconnect('wss://test.livekit.io', 'test-token', 'sid-123');

      expect(result).toEqual(reconnectResponse);
      expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
    });

    it('should handle reconnect with non-reconnect message (edge case)', async () => {
      // First, initial connection
      const joinResponse = createJoinResponse();
      const joinSignalResponse = createSignalResponse('join', joinResponse);
      const initialMockReadable = createMockReadableStream([joinSignalResponse]);
      const initialMockConnection = createMockConnection(initialMockReadable);

      mockWebSocketStream({ connection: initialMockConnection });

      await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

      // Setup reconnect with non-reconnect message (e.g., participant update)
      const updateSignalResponse = createSignalResponse('update', { participants: [] });
      const reconnectMockReadable = createMockReadableStream([updateSignalResponse]);
      const reconnectMockConnection = createMockConnection(reconnectMockReadable);

      mockWebSocketStream({ connection: reconnectMockConnection });

      const result = await signalClient.reconnect('wss://test.livekit.io', 'test-token', 'sid-123');

      // This is an edge case: reconnect resolves with undefined when non-reconnect message is received
      expect(result).toBeUndefined();
      expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
    }, 1000);
  });

  describe('Failure Case - Timeout', () => {
    it('should reject with timeout error when websocket connection takes too long', async () => {
      mockWebSocketStream({ readyState: 0 }); // Never resolves

      const shortTimeoutOptions = {
        ...defaultOptions,
        websocketTimeout: 100,
      };

      const error = await signalClient
        .join('wss://test.livekit.io', 'test-token', shortTimeoutOptions)
        .catch((e) => e);

      expect(error).toBeInstanceOf(ConnectionError);
      expect(error.reason).toBe(ConnectionErrorReason.Cancelled);
    });
  });

  describe('Failure Case - AbortSignal', () => {
    it('should reject when AbortSignal is triggered', async () => {
      const abortController = new AbortController();

      vi.mocked(WebSocketStream).mockImplementation(function () {
        // Simulate abort
        setTimeout(() => abortController.abort(new Error('User aborted connection')), 50);

        return {
          url: 'wss://test.livekit.io',
          opened: new Promise(() => {}), // Never resolves
          closed: new Promise(() => {}),
          close: vi.fn(),
          readyState: 0,
        } as any;
      });

      await expect(
        signalClient.join(
          'wss://test.livekit.io',
          'test-token',
          defaultOptions,
          abortController.signal,
        ),
      ).rejects.toThrow('User aborted connection');
    });

    it('should send leave request before closing when AbortSignal is triggered during connection', async () => {
      const abortController = new AbortController();
      const writtenMessages: Array<ArrayBuffer | string> = [];
      let streamWriterReady: (() => void) | undefined;
      const streamWriterReadyPromise = new Promise<void>((resolve) => {
        streamWriterReady = resolve;
      });

      // Create a mock writable stream that captures writes
      const mockWritable = new WritableStream({
        write(chunk) {
          writtenMessages.push(chunk);
          return Promise.resolve();
        },
      });

      // Override getWriter to signal when streamWriter is assigned
      const originalGetWriter = mockWritable.getWriter.bind(mockWritable);
      mockWritable.getWriter = () => {
        const writer = originalGetWriter();
        streamWriterReady?.();
        return writer;
      };

      const mockReadable = new ReadableStream<ArrayBuffer>({
        async start() {
          // Keep connection open but don't send join response yet
          // This simulates aborting during connection (after WS opens, before join response)
        },
      });

      const mockConnection = {
        readable: mockReadable,
        writable: mockWritable,
        protocol: '',
        extensions: '',
      };

      vi.mocked(WebSocketStream).mockImplementation(function () {
        return {
          url: 'wss://test.livekit.io',
          opened: Promise.resolve(mockConnection),
          closed: new Promise(() => {}),
          close: vi.fn(),
          readyState: 1,
        } as any;
      });

      // Start the connection
      const joinPromise = signalClient.join(
        'wss://test.livekit.io',
        'test-token',
        defaultOptions,
        abortController.signal,
      );

      // Wait for streamWriter to be assigned
      await streamWriterReadyPromise;

      // Now abort the connection (after WS opens, before join response)
      abortController.abort(new Error('User aborted connection'));

      // joinPromise should reject
      await expect(joinPromise).rejects.toThrow('User aborted connection');

      // Verify that a leave request was sent before closing
      const leaveRequestSent = writtenMessages.some((data) => {
        if (typeof data === 'string') {
          return false;
        }
        try {
          const request = SignalRequest.fromBinary(
            data instanceof ArrayBuffer ? new Uint8Array(data) : data,
          );
          return request.message?.case === 'leave';
        } catch {
          return false;
        }
      });

      expect(leaveRequestSent).toBe(true);
    });
  });

  describe('Failure Case - WebSocket Connection Errors', () => {
    it('should reject with NotAllowed error for 4xx HTTP status', async () => {
      const openedPromise = Promise.reject(new Error('Connection failed'));
      openedPromise.catch(() => {}); // prevent unhandled rejection before join attaches its handler
      mockWebSocketStream({
        opened: openedPromise,
        readyState: 3,
      });

      // Mock fetch to return 403
      (global.fetch as any).mockResolvedValueOnce({
        status: 403,
        text: async () => 'Forbidden',
      });

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject({
        message: 'Forbidden',
        reason: ConnectionErrorReason.NotAllowed,
        status: 403,
      });
    });

    it('should reject with ServerUnreachable when fetch fails', async () => {
      const openedPromise = Promise.reject(new Error('Connection failed'));
      openedPromise.catch(() => {}); // prevent unhandled rejection before join attaches its handler
      mockWebSocketStream({
        opened: openedPromise,
        readyState: 3,
      });

      // Mock fetch to throw (network error)
      (global.fetch as any).mockRejectedValueOnce(new Error('Network error'));

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject({
        reason: ConnectionErrorReason.ServerUnreachable,
      });
    });

    it('should handle ConnectionError from WebSocket rejection', async () => {
      const customError = ConnectionError.internal('Custom error', { status: 500 });
      const openedPromise = Promise.reject(customError);
      openedPromise.catch(() => {}); // prevent unhandled rejection before join attaches its handler
      mockWebSocketStream({
        opened: openedPromise,
        readyState: 3,
      });

      // Mock fetch to return 500
      (global.fetch as any).mockResolvedValueOnce({
        status: 500,
        text: async () => 'Internal Server Error',
      });

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject({
        reason: ConnectionErrorReason.InternalError,
      });
    });
  });

  describe('Failure Case - No First Message', () => {
    it('should reject when no first message is received', async () => {
      // Close the stream immediately without sending a message
      const mockReadable = new ReadableStream<ArrayBuffer>({
        async start(controller) {
          controller.close();
        },
      });
      const mockConnection = createMockConnection(mockReadable);

      mockWebSocketStream({ connection: mockConnection });

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject({
        message: 'no message received as first message',
        reason: ConnectionErrorReason.InternalError,
      });
    });
  });

  describe('Failure Case - Leave Request During Connection', () => {
    it('should reject when receiving leave request during initial join', async () => {
      const leaveRequest = new LeaveRequest({
        reason: 1, // Some disconnect reason
      });
      const signalResponse = createSignalResponse('leave', leaveRequest);
      const mockReadable = createMockReadableStream([signalResponse]);
      const mockConnection = createMockConnection(mockReadable);

      mockWebSocketStream({ connection: mockConnection });

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject(
        ConnectionError.leaveRequest(
          'Received leave request while trying to (re)connect',
          DisconnectReason.CLIENT_INITIATED,
        ),
      );
    });
  });

  describe('Failure Case - Wrong Message Type for Non-Reconnect', () => {
    it('should reject when receiving non-join message on initial connection', async () => {
      // Send a reconnect response instead of join (wrong for initial connection)
      const reconnectResponse = new ReconnectResponse({
        iceServers: [],
      });
      const signalResponse = createSignalResponse('reconnect', reconnectResponse);
      const mockReadable = createMockReadableStream([signalResponse]);
      const mockConnection = createMockConnection(mockReadable);

      mockWebSocketStream({ connection: mockConnection });

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject({
        message: 'did not receive join response, got reconnect instead',
        reason: ConnectionErrorReason.InternalError,
      });
    });
  });

  describe('Failure Case - WebSocket Closed During Connection', () => {
    it('should reject when WebSocket closes during connection attempt', async () => {
      let closedResolve: (value: WebSocketCloseInfo) => void;
      const closedPromise = new Promise<WebSocketCloseInfo>((resolve) => {
        closedResolve = resolve;
      });

      vi.mocked(WebSocketStream).mockImplementation(function () {
        // Simulate close during connection
        queueMicrotask(() => {
          closedResolve({ closeCode: 1006, reason: 'Connection lost' });
        });

        return {
          url: 'wss://test.livekit.io',
          opened: new Promise(() => {}), // Never resolves
          closed: closedPromise,
          close: vi.fn(),
          readyState: 2, // CLOSING
        } as any;
      });

      await expect(
        signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions),
      ).rejects.toMatchObject({
        message: 'Websocket got closed during a (re)connection attempt: Connection lost',
        reason: ConnectionErrorReason.InternalError,
      });
    });
  });

  describe('Edge Cases and State Management', () => {
    it('should set state to CONNECTING when joining', async () => {
      expect(signalClient.currentState).toBe(SignalConnectionState.DISCONNECTED);

      const joinResponse = createJoinResponse();
      const signalResponse = createSignalResponse('join', joinResponse);
      const mockReadable = createMockReadableStream([signalResponse]);
      const mockConnection = createMockConnection(mockReadable);

      mockWebSocketStream({ connection: mockConnection });

      const joinPromise = signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

      // State should be CONNECTING before connection completes
      expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTING);

      await joinPromise;

      expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
    });
  });

  describe('ilimo subscriber slots', () => {
    it('advertises subscriber_slots and delivers the slot updates once negotiated', async () => {
      const joinResponse = createJoinResponse();
      joinResponse.serverInfo = withIlimoCapabilities(new ServerInfo(), [
        SUBSCRIBER_SLOTS_CAPABILITY,
      ]);
      const slotUpdate = SignalResponse.fromBinary(
        new BinaryWriter()
          .tag(100, WireType.LengthDelimited)
          .bytes(
            new BinaryWriter()
              .tag(1, WireType.LengthDelimited)
              .bytes(
                new BinaryWriter()
                  .tag(1, WireType.LengthDelimited)
                  .bytes(new BinaryWriter().tag(1, WireType.LengthDelimited).string('7').finish())
                  .finish(),
              )
              .finish(),
          )
          .finish(),
      );
      let url = '';
      mockWebSocketStream({
        connection: createMockConnection(
          createMockReadableStream([createSignalResponse('join', joinResponse), slotUpdate]),
        ),
        onUrl: (u) => {
          url = u;
        },
      });
      const received: string[] = [];
      signalClient.onSlotUpdate = (slots) => received.push(...slots.map((slot) => slot.mid));

      await signalClient.join('wss://test.livekit.io', 'test-token', {
        ...defaultOptions,
        singlePeerConnection: true,
        subscriberSlots: true,
      });
      await new Promise((resolve) => setTimeout(resolve, 0));

      const joinRequest = await decodeJoinRequestFromUrl(url);
      expect(readIlimoCapabilities(joinRequest.clientInfo!)).toEqual([SUBSCRIBER_SLOTS_CAPABILITY]);
      expect(signalClient.subscriberSlots).toBe(true);
      expect(received).toEqual(['7']);
    });
  });
});

describe('SignalClient over ilimo _signal', () => {
  const options = {
    autoSubscribe: true,
    maxRetries: 0,
    e2eeEnabled: false,
    websocketTimeout: 1000,
    singlePeerConnection: true,
    signalOverDataChannel: true,
  };

  function mockDataChannel() {
    return {
      readyState: 'open',
      send: vi.fn(),
      onmessage: null as ((event: MessageEvent) => void) | null,
      onclose: null as (() => void) | null,
    };
  }

  function sentRequests(dc: ReturnType<typeof mockDataChannel>): SignalRequest[] {
    return dc.send.mock.calls.map(([frame]) =>
      SignalRequest.fromBinary(decodeSignalFramePayload(frame as Uint8Array)!),
    );
  }

  async function joinWithServerClose() {
    vi.clearAllMocks();
    const joinResponse = createJoinResponse();
    joinResponse.serverInfo = withIlimoCapabilities(new ServerInfo(), [
      SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
    ]);
    let serverClose: (info: WebSocketCloseInfo) => void = () => {};
    const closed = new Promise<WebSocketCloseInfo>((resolve) => {
      serverClose = resolve;
    });
    const writes: Uint8Array[] = [];
    const connection = createMockConnection(
      createMockReadableStream([createSignalResponse('join', joinResponse)]),
    );
    connection.writable = new WritableStream({
      write(chunk) {
        writes.push(chunk as Uint8Array);
      },
    });
    mockWebSocketStream({ connection, closed });
    const signalClient = new SignalClient(false);
    await signalClient.join('wss://test.livekit.io', 'test-token', options);
    return { signalClient, serverClose, writes };
  }

  it('holds requests after ilimo closes the WebSocket, then sends them on _signal', async () => {
    const { signalClient, serverClose, writes } = await joinWithServerClose();
    serverClose({ closeCode: 1000, reason: 'signal over data channel' });
    await new Promise((resolve) => setTimeout(resolve, 0));

    const writesBefore = writes.length;
    signalClient.sendMuteTrack('TR_held', true);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(writes.length).toBe(writesBefore);

    const dc = mockDataChannel();
    expect(signalClient.switchToDataChannel(dc as unknown as RTCDataChannel)).toBe(true);
    await new Promise((resolve) => setTimeout(resolve, 0));

    const sent = sentRequests(dc);
    expect(sent).toHaveLength(1);
    expect(sent[0].message.case).toBe('mute');
    expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
  });

  async function joinWithOpenStream() {
    vi.clearAllMocks();
    const joinResponse = createJoinResponse();
    joinResponse.serverInfo = withIlimoCapabilities(new ServerInfo(), [
      SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
    ]);
    let push: (response: SignalResponse) => void = () => {};
    const readable = new ReadableStream<ArrayBuffer>({
      start(controller) {
        controller.enqueue(
          createSignalResponse('join', joinResponse).toBinary().buffer as ArrayBuffer,
        );
        push = (response) => controller.enqueue(response.toBinary().buffer as ArrayBuffer);
      },
    });
    mockWebSocketStream({ connection: createMockConnection(readable) });
    const signalClient = new SignalClient(false);
    await signalClient.join('wss://test.livekit.io', 'test-token', options);
    return { signalClient, push };
  }

  it('reads the WebSocket after the switch, until ilimo closes it', async () => {
    const { signalClient, push } = await joinWithOpenStream();
    const published: string[] = [];
    signalClient.onLocalTrackPublished = (res) => published.push(res.cid);

    const dc = mockDataChannel();
    expect(signalClient.switchToDataChannel(dc as unknown as RTCDataChannel)).toBe(true);
    const ws = (signalClient as unknown as { ws: { close: ReturnType<typeof vi.fn> } }).ws;
    expect(ws.close).not.toHaveBeenCalled();

    push(
      new SignalResponse({
        message: { case: 'trackPublished', value: new TrackPublishedResponse({ cid: 'cam' }) },
      }),
    );
    await new Promise((resolve) => setTimeout(resolve, 20));
    expect(published).toEqual(['cam']);
    expect(ws.close).not.toHaveBeenCalled();
  });

  it('closes the WebSocket itself if ilimo has not after the switch', async () => {
    const { signalClient } = await joinWithOpenStream();
    vi.useFakeTimers();
    try {
      const dc = mockDataChannel();
      signalClient.switchToDataChannel(dc as unknown as RTCDataChannel);
      const ws = (signalClient as unknown as { ws: { close: ReturnType<typeof vi.fn> } }).ws;
      await vi.advanceTimersByTimeAsync(WEBSOCKET_DRAIN_MS - 1);
      expect(ws.close).not.toHaveBeenCalled();
      await vi.advanceTimersByTimeAsync(1);
      expect(ws.close).toHaveBeenCalled();
    } finally {
      vi.useRealTimers();
    }
  });

  it('resumes on a new WebSocket, still reading _signal without sending on it', async () => {
    const { signalClient } = await joinWithServerClose();
    const onClose = vi.fn();
    signalClient.onClose = onClose;
    const dc = mockDataChannel();
    expect(signalClient.switchToDataChannel(dc as unknown as RTCDataChannel)).toBe(true);

    const writes: Uint8Array[] = [];
    const connection = createMockConnection(
      createMockReadableStream([createSignalResponse('reconnect', new ReconnectResponse({}))]),
    );
    connection.writable = new WritableStream({
      write(chunk) {
        writes.push(chunk as Uint8Array);
      },
    });
    mockWebSocketStream({ connection });
    await signalClient.reconnect('wss://test.livekit.io', 'test-token', 'participant-sid');
    expect(signalClient.isOnDataChannel).toBe(false);

    const sentBefore = dc.send.mock.calls.length;
    signalClient.sendMuteTrack('TR_resumed', true);
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(dc.send.mock.calls.length).toBe(sentBefore);
    expect(
      writes.map((write) => SignalRequest.fromBinary(new Uint8Array(write)).message.case),
    ).toContain('mute');

    // A frame ilimo sent before the cut may still come in on `_signal`.
    const onLeave = vi.fn();
    signalClient.onLeave = onLeave;
    const frame = encodeSignalFrame(
      7,
      createSignalResponse('leave', new LeaveRequest({})).toBinary(),
    );
    dc.onmessage!({
      data: frame.buffer.slice(frame.byteOffset, frame.byteOffset + frame.byteLength),
    } as MessageEvent);
    expect(onLeave).toHaveBeenCalledTimes(1);
    expect(dc.onclose).toBeNull();
    expect(onClose).not.toHaveBeenCalled();
  });

  it('reads _signal from its opening, before the switch', async () => {
    const { signalClient } = await joinWithServerClose();
    const onLeave = vi.fn();
    signalClient.onLeave = onLeave;

    const dc = mockDataChannel();
    signalClient.listenOnDataChannel(dc as unknown as RTCDataChannel);
    expect(dc.onmessage).not.toBeNull();

    const response = createSignalResponse('leave', new LeaveRequest({}));
    const frame = encodeSignalFrame(1, response.toBinary());
    dc.onmessage!({
      data: frame.buffer.slice(frame.byteOffset, frame.byteOffset + frame.byteLength),
    } as MessageEvent);
    expect(onLeave).toHaveBeenCalledTimes(1);
    expect(signalClient.isOnDataChannel).toBe(false);
  });

  it('keeps pinging over _signal after the switch', async () => {
    vi.useFakeTimers();
    try {
      const { signalClient } = await joinWithServerClose();
      const onClose = vi.fn();
      signalClient.onClose = onClose;
      const dc = mockDataChannel();
      expect(signalClient.switchToDataChannel(dc as unknown as RTCDataChannel)).toBe(true);
      // The WebSocket close waits up to MAX_WS_CLOSE_TIME, then a ping every 10 s; the pong
      // timeout is 30 s.
      await vi.advanceTimersByTimeAsync(20_000);

      const pings = sentRequests(dc).filter((req) => req.message.case === 'pingReq');
      expect(pings.length).toBeGreaterThan(0);
      expect(onClose).not.toHaveBeenCalled();
    } finally {
      vi.useRealTimers();
    }
  });

  it('counts the close as a disconnect if _signal never takes over', async () => {
    vi.useFakeTimers();
    try {
      const { signalClient, serverClose } = await joinWithServerClose();
      const onClose = vi.fn();
      signalClient.onClose = onClose;
      serverClose({ closeCode: 1000, reason: 'signal over data channel' });
      await vi.advanceTimersByTimeAsync(2000);
      expect(onClose).not.toHaveBeenCalled();
      await vi.advanceTimersByTimeAsync(2000);
      expect(onClose).toHaveBeenCalledTimes(1);
    } finally {
      vi.useRealTimers();
    }
  });
});

describe('SignalClient utility functions', () => {
  describe('toProtoSessionDescription', () => {
    it('should convert RTCSessionDescriptionInit to proto SessionDescription', async () => {
      const { toProtoSessionDescription } = await import('./SignalClient');

      const rtcDesc: RTCSessionDescriptionInit = {
        type: 'offer',
        sdp: 'v=0\r\no=- 123 456 IN IP4 127.0.0.1\r\n',
      };

      const protoDesc = toProtoSessionDescription(rtcDesc, 42);

      expect(protoDesc.type).toBe('offer');
      expect(protoDesc.sdp).toBe('v=0\r\no=- 123 456 IN IP4 127.0.0.1\r\n');
      expect(protoDesc.id).toBe(42);
    });

    it('should handle answer type', async () => {
      const { toProtoSessionDescription } = await import('./SignalClient');

      const rtcDesc: RTCSessionDescriptionInit = {
        type: 'answer',
        sdp: 'v=0\r\n',
      };

      const protoDesc = toProtoSessionDescription(rtcDesc);

      expect(protoDesc.type).toBe('answer');
      expect(protoDesc.sdp).toBe('v=0\r\n');
    });
  });
});

describe('SignalClient.handleSignalConnected', () => {
  let signalClient: SignalClient;

  const defaultOptions = {
    autoSubscribe: true,
    maxRetries: 0,
    e2eeEnabled: false,
    websocketTimeout: 1000,
    singlePeerConnection: false,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    signalClient = new SignalClient(false);
  });

  it('should set state to CONNECTED', () => {
    const mockReadable = new ReadableStream<ArrayBuffer>();
    const mockConnection = createMockConnection(mockReadable);

    // Access the method through a type assertion for testing
    const handleMethod = (signalClient as any).handleSignalConnected;
    if (handleMethod) {
      handleMethod.call(signalClient, mockConnection);
      expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
    }
  });

  it('should start reading loop without first message', async () => {
    const joinResponse = createJoinResponse();
    const signalResponse = createSignalResponse('join', joinResponse);
    const mockReadable = createMockReadableStream([signalResponse]);
    const mockConnection = createMockConnection(mockReadable);

    mockWebSocketStream({ connection: mockConnection });

    await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

    // Verify connection was established successfully
    expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
  });

  it('should start reading loop with first message', async () => {
    const joinResponse = createJoinResponse();
    const signalResponse = createSignalResponse('join', joinResponse);
    const mockReadable = createMockReadableStream([signalResponse]);
    const mockConnection = createMockConnection(mockReadable);

    mockWebSocketStream({ connection: mockConnection });

    await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

    expect(signalClient.currentState).toBe(SignalConnectionState.CONNECTED);
  });
});

describe('SignalClient.validateFirstMessage', () => {
  let signalClient: SignalClient;

  const defaultOptions = {
    autoSubscribe: true,
    maxRetries: 0,
    e2eeEnabled: false,
    websocketTimeout: 1000,
    singlePeerConnection: false,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    signalClient = new SignalClient(false);
  });

  it('should accept join response for initial connection', () => {
    const joinResponse = createJoinResponse();
    const signalResponse = createSignalResponse('join', joinResponse);

    const validateMethod = (signalClient as any).validateFirstMessage;
    if (validateMethod) {
      const result = validateMethod.call(signalClient, signalResponse, false);
      expect(result.isValid).toBe(true);
      expect(result.response).toEqual(joinResponse);
    }
  });

  it('should accept reconnect response for reconnection', async () => {
    // First establish a connection to set options
    const joinResponse = createJoinResponse();
    const joinSignalResponse = createSignalResponse('join', joinResponse);
    const initialMockReadable = createMockReadableStream([joinSignalResponse]);
    const initialMockConnection = createMockConnection(initialMockReadable);

    mockWebSocketStream({ connection: initialMockConnection });
    await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

    // Set state to RECONNECTING to match the validation logic
    (signalClient as any).state = SignalConnectionState.RECONNECTING;

    const reconnectResponse = new ReconnectResponse({ iceServers: [] });
    const signalResponse = createSignalResponse('reconnect', reconnectResponse);

    const validateMethod = (signalClient as any).validateFirstMessage;
    if (validateMethod) {
      const result = validateMethod.call(signalClient, signalResponse, true);
      expect(result.isValid).toBe(true);
      expect(result.response).toEqual(reconnectResponse);
    }
  });

  it('should accept non-reconnect message during reconnecting state', async () => {
    // First establish a connection
    const joinResponse = createJoinResponse();
    const joinSignalResponse = createSignalResponse('join', joinResponse);
    const initialMockReadable = createMockReadableStream([joinSignalResponse]);
    const initialMockConnection = createMockConnection(initialMockReadable);

    mockWebSocketStream({ connection: initialMockConnection });
    await signalClient.join('wss://test.livekit.io', 'test-token', defaultOptions);

    // Set state to reconnecting
    (signalClient as any).state = SignalConnectionState.RECONNECTING;

    const updateSignalResponse = createSignalResponse('update', { participants: [] });

    const validateMethod = (signalClient as any).validateFirstMessage;
    if (validateMethod) {
      const result = validateMethod.call(signalClient, updateSignalResponse, true);
      expect(result.isValid).toBe(true);
      expect(result.response).toBeUndefined();
      expect(result.shouldProcessFirstMessage).toBe(true);
    }
  });

  it('should reject leave request during connection attempt', () => {
    // Set state to CONNECTING to be in establishing connection state
    (signalClient as any).state = SignalConnectionState.CONNECTING;

    const leaveRequest = new LeaveRequest({ reason: 1 });
    const signalResponse = createSignalResponse('leave', leaveRequest);

    const validateMethod = (signalClient as any).validateFirstMessage;
    if (validateMethod) {
      const result = validateMethod.call(signalClient, signalResponse, false);
      expect(result.isValid).toBe(false);
      expect(result.error).toBeInstanceOf(ConnectionError);
      expect(result.error?.reason).toBe(ConnectionErrorReason.LeaveRequest);
    }
  });

  it('should reject non-join message for initial connection', () => {
    const reconnectResponse = new ReconnectResponse({ iceServers: [] });
    const signalResponse = createSignalResponse('reconnect', reconnectResponse);

    const validateMethod = (signalClient as any).validateFirstMessage;
    if (validateMethod) {
      const result = validateMethod.call(signalClient, signalResponse, false);
      expect(result.isValid).toBe(false);
      expect(result.error).toBeInstanceOf(ConnectionError);
      expect(result.error?.reason).toBe(ConnectionErrorReason.InternalError);
    }
  });
});

describe('SignalClient.handleConnectionError', () => {
  let signalClient: SignalClient;

  beforeEach(() => {
    vi.clearAllMocks();
    signalClient = new SignalClient(false);
  });

  it('should return NotAllowed error for 4xx HTTP status', async () => {
    (global.fetch as any).mockResolvedValueOnce({
      status: 403,
      text: async () => 'Forbidden',
    });

    const handleMethod = (signalClient as any).handleConnectionError;
    if (handleMethod) {
      const error = new Error('Connection failed');
      const result = await handleMethod.call(signalClient, error, 'wss://test.livekit.io/validate');

      expect(result).toBeInstanceOf(ConnectionError);
      expect(result.reason).toBe(ConnectionErrorReason.NotAllowed);
      expect(result.status).toBe(403);
      expect(result.message).toBe('Forbidden');
    }
  });

  it('should return ConnectionError as-is if it is already a ConnectionError', async () => {
    const connectionError = ConnectionError.internal('Custom error');

    (global.fetch as any).mockResolvedValueOnce({
      status: 500,
      text: async () => 'Internal Server Error',
    });

    const handleMethod = (signalClient as any).handleConnectionError;
    if (handleMethod) {
      const result = await handleMethod.call(
        signalClient,
        connectionError,
        'wss://test.livekit.io/validate',
      );

      expect(result).toBe(connectionError);
      expect(result.reason).toBe(ConnectionErrorReason.InternalError);
    }
  });

  it('should return InternalError for non-4xx HTTP status', async () => {
    (global.fetch as any).mockResolvedValueOnce({
      status: 500,
      text: async () => 'Internal Server Error',
    });

    const handleMethod = (signalClient as any).handleConnectionError;
    if (handleMethod) {
      const error = new Error('Connection failed');
      const result = await handleMethod.call(signalClient, error, 'wss://test.livekit.io/validate');

      expect(result).toBeInstanceOf(ConnectionError);
      expect(result.reason).toBe(ConnectionErrorReason.InternalError);
    }
  });

  it('should return ServerUnreachable when fetch fails', async () => {
    (global.fetch as any).mockRejectedValueOnce(new Error('Network error'));

    const handleMethod = (signalClient as any).handleConnectionError;
    if (handleMethod) {
      const error = new Error('Connection failed');
      const result = await handleMethod.call(signalClient, error, 'wss://test.livekit.io/validate');

      expect(result).toBeInstanceOf(ConnectionError);
      expect(result.reason).toBe(ConnectionErrorReason.ServerUnreachable);
    }
  });

  it('should handle fetch throwing ConnectionError', async () => {
    const fetchError = ConnectionError.serverUnreachable('Fetch failed');
    (global.fetch as any).mockRejectedValueOnce(fetchError);

    const handleMethod = (signalClient as any).handleConnectionError;
    if (handleMethod) {
      const error = new Error('Connection failed');
      const result = await handleMethod.call(signalClient, error, 'wss://test.livekit.io/validate');

      expect(result).toBe(fetchError);
    }
  });
});
