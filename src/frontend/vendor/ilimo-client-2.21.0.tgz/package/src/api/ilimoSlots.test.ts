// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
import { BinaryWriter, WireType } from '@bufbuild/protobuf';
import { Pong, SignalResponse } from '@livekit/protocol';
import { describe, expect, it } from 'vitest';
import { type IlimoSlot, readSlotUpdate } from './ilimoSlots';

/** A SignalResponse carrying `slots` the way ilimo sends them (field 100, IlimoResponse). */
function slotUpdateResponse(slots: IlimoSlot[]): SignalResponse {
  const update = new BinaryWriter();
  for (const slot of slots) {
    const entry = new BinaryWriter()
      .tag(1, WireType.LengthDelimited)
      .string(slot.mid)
      .tag(2, WireType.LengthDelimited)
      .string(slot.participantSid)
      .tag(3, WireType.LengthDelimited)
      .string(slot.trackSid)
      .tag(4, WireType.Varint)
      .uint32(slot.rtpTimestamp)
      .finish();
    update.tag(1, WireType.LengthDelimited).bytes(entry);
  }
  const ilimo = new BinaryWriter().tag(1, WireType.LengthDelimited).bytes(update.finish()).finish();
  const response = new BinaryWriter().tag(100, WireType.LengthDelimited).bytes(ilimo).finish();
  return SignalResponse.fromBinary(response);
}

describe('ilimoSlots', () => {
  it('reads the slots of a SlotUpdate', () => {
    const slots = [
      { mid: '3', participantSid: 'PA_a', trackSid: 'TR_a', rtpTimestamp: 4_294_967_000 },
      { mid: '4', participantSid: '', trackSid: '', rtpTimestamp: 0 },
    ];
    const response = slotUpdateResponse(slots);
    expect(response.message.case).toBeUndefined();
    expect(readSlotUpdate(response)).toEqual(slots);
  });

  it('ignores any other response', () => {
    const pong = new SignalResponse({ message: { case: 'pongResp', value: new Pong() } });
    expect(readSlotUpdate(pong)).toBeUndefined();
  });
});
