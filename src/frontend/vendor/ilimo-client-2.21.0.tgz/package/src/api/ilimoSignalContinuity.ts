// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// ilimo's `signal_continuity` (P0-29b): `_signal` frames carry cumulative acknowledgments and
// fragments, and each side keeps its frames until acknowledged, to replay them on the new
// WebSocket of a resume, wrapped in field 100 of SignalRequest/SignalResponse. The same rules as
// crates/ilimo/src/signal_dc.rs and docs/specs/protocol-extensions.md in the ilimo repo.
import { BinaryWriter, type Message, WireType } from '@bufbuild/protobuf';
import { type SignalFrame, decodeSignalFrame, encodeSignalFrame } from './ilimoSignalFrame';
import { lengthDelimited } from './ilimoSlots';

/** Largest payload of one frame: a longer message goes in several. */
export const FRAGMENT_BYTES = 64 * 1024;
/** How long a received frame may wait for its acknowledgment. */
export const ACK_DELAY_MS = 200;
/** Bytes of frames kept until acknowledged; beyond, the oldest are forgotten. */
const REPLAY_BYTES = 1024 * 1024;
/** Largest response reassembled from fragments. */
const MAX_RESPONSE_BYTES = 16 * 1024 * 1024;

const ILIMO_FIELD = 100;
const RESPONSE_SIGNAL_FRAME_FIELD = 2;
const REQUEST_SIGNAL_FRAME_FIELD = 1;

/** The frames this side sends on `_signal`, numbered, kept until acknowledged. */
export class SignalOutbox {
  private seq = 0;

  private kept: SignalFrame[] = [];

  private keptBytes = 0;

  /** A frame was forgotten before its acknowledgment: a replay would miss it. */
  lost = false;

  constructor(private readonly continuity: boolean) {}

  /** Numbers `message`, in fragments under `signal_continuity`, and returns the frames to send. */
  push(message: Uint8Array): SignalFrame[] {
    if (!this.continuity) {
      this.seq += 1;
      return [{ seq: this.seq, payload: message }];
    }
    const frames: SignalFrame[] = [];
    let offset = 0;
    do {
      const payload = message.subarray(offset, offset + FRAGMENT_BYTES);
      offset += FRAGMENT_BYTES;
      this.seq += 1;
      frames.push({ seq: this.seq, payload, more: offset < message.length });
    } while (offset < message.length);
    for (const frame of frames) {
      this.kept.push(frame);
      this.keptBytes += frame.payload.length;
    }
    while (this.keptBytes > REPLAY_BYTES) {
      this.forgetFirst();
      this.lost = true;
    }
    return frames;
  }

  /** Forgets the frames up to `ack`, which the other side received. */
  acknowledge(ack: number) {
    while (this.kept.length > 0 && this.kept[0].seq <= ack) {
      this.forgetFirst();
    }
  }

  /** Every frame not acknowledged yet, oldest first. */
  replay(): SignalFrame[] {
    return [...this.kept];
  }

  private forgetFirst() {
    const first = this.kept.shift();
    if (first) {
      this.keptBytes -= first.payload.length;
    }
  }
}

/**
 * The frames this side receives, on `_signal` or replayed on the WebSocket: under
 * `signal_continuity`, duplicates dropped and fragments reassembled.
 */
export class SignalInbox {
  /** The last frame received in order, which every frame sent acknowledges. */
  received = 0;

  /** A frame was received since the last acknowledgment sent. */
  ackDue = false;

  private partial: Uint8Array[] = [];

  private partialBytes = 0;

  private skipping = false;

  constructor(private readonly continuity: boolean) {}

  /** Takes `frame` in; returns the message it completes, if any. Throws if frames are missing. */
  receive(frame: SignalFrame): Uint8Array | undefined {
    if (!this.continuity) {
      this.received = Math.max(this.received, frame.seq);
      return frame.payload;
    }
    if (frame.seq === 0 || frame.seq <= this.received) {
      return undefined;
    }
    if (frame.seq !== this.received + 1) {
      throw new Error(`signal frame ${frame.seq} after frame ${this.received}, frames missing`);
    }
    this.received = frame.seq;
    this.ackDue = true;
    if (this.skipping) {
      this.skipping = !!frame.more;
      return undefined;
    }
    if (this.partialBytes + frame.payload.length > MAX_RESPONSE_BYTES) {
      this.partial = [];
      this.partialBytes = 0;
      this.skipping = !!frame.more;
      throw new Error(`signal message over ${MAX_RESPONSE_BYTES} bytes, dropped`);
    }
    if (frame.more) {
      this.partial.push(frame.payload.slice());
      this.partialBytes += frame.payload.length;
      return undefined;
    }
    if (this.partial.length === 0) {
      return frame.payload;
    }
    const message = new Uint8Array(this.partialBytes + frame.payload.length);
    let offset = 0;
    for (const part of [...this.partial, frame.payload]) {
      message.set(part, offset);
      offset += part.length;
    }
    this.partial = [];
    this.partialBytes = 0;
    return message;
  }

  /** An acknowledgment alone, without payload. */
  ackFrame(): SignalFrame {
    return { seq: 0, payload: new Uint8Array(), ack: this.received };
  }
}

/** The `_signal` frame a WebSocket response carries in IlimoResponse.signal_frame, if any. */
export function readIlimoSignalFrame(response: Message): SignalFrame | undefined {
  try {
    const ilimo = lengthDelimited(response.toBinary(), ILIMO_FIELD);
    const frame = ilimo && lengthDelimited(ilimo, RESPONSE_SIGNAL_FRAME_FIELD);
    return frame && decodeSignalFrame(frame);
  } catch {
    return undefined;
  }
}

/** A SignalRequest carrying `frame` in IlimoRequest.signal_frame, encoded for the WebSocket. */
export function encodeIlimoRequestFrame(frame: SignalFrame): Uint8Array {
  const request = new BinaryWriter();
  request.tag(REQUEST_SIGNAL_FRAME_FIELD, WireType.LengthDelimited).bytes(encodeSignalFrame(frame));
  const signal = new BinaryWriter();
  signal.tag(ILIMO_FIELD, WireType.LengthDelimited).bytes(request.finish());
  return signal.finish();
}
