// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
import { ClientInfo, ServerInfo } from '@livekit/protocol';
import { describe, expect, it } from 'vitest';
import {
  SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
  readIlimoCapabilities,
  withIlimoCapabilities,
} from './ilimoCapabilities';

describe('ilimoCapabilities', () => {
  it('round-trips through a direct marshal/unmarshal', () => {
    const withCaps = withIlimoCapabilities(new ClientInfo({ version: '2.21.0' }), [
      SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
      'another_capability',
    ]);

    const decoded = ClientInfo.fromBinary(withCaps.toBinary());
    expect(decoded.version).toBe('2.21.0');
    expect(readIlimoCapabilities(decoded)).toEqual([
      SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
      'another_capability',
    ]);
  });

  it('survives being embedded in and re-extracted from a parent message', () => {
    // Mirrors how ClientInfo travels inside a JoinRequest, and ServerInfo inside a JoinResponse.
    const withCaps = withIlimoCapabilities(new ServerInfo({ version: '0.0.0' }), [
      SIGNAL_OVER_DATA_CHANNEL_CAPABILITY,
    ]);
    const roundTripped = ServerInfo.fromBinary(withCaps.toBinary());
    expect(readIlimoCapabilities(roundTripped)).toEqual([SIGNAL_OVER_DATA_CHANNEL_CAPABILITY]);
  });

  it('returns an empty list for a message without the field', () => {
    expect(readIlimoCapabilities(new ServerInfo({ version: '1.13.7' }))).toEqual([]);
  });
});
