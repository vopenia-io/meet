// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// ilimo_capabilities (ClientInfo/ServerInfo field 100, `repeated string`) negotiates ilimo-only
// protocol extensions — currently just signal_over_dc (see ilimoSignalFrame.ts). It exists only in
// ilimo's vendored proto (crates/ilimo-protocol/vendor/livekit-protocol/protobufs/livekit_models.proto,
// its vendor/README.md's "Exception ilimo (P0-23)" section), not in upstream `@livekit/protocol` —
// forking that package for one field was out of scope for this fork, so it's encoded/decoded
// directly at the wire level instead. `@bufbuild/protobuf` v1 preserves unknown fields transparently
// across `fromBinary`/`toBinary` (including through a parent message that embeds this one), so a
// ClientInfo built this way round-trips its extra field correctly when embedded in a JoinRequest —
// verified directly, not just assumed.
import { BinaryReader, BinaryWriter, type Message, WireType } from '@bufbuild/protobuf';

/** Negotiates `_signal`: WebSocket until in conference, ilimo's data channel after. */
export const SIGNAL_OVER_DATA_CHANNEL_CAPABILITY = 'signal_over_dc';

/** Negotiates receiving through a fixed set of sections (see ilimoSlots.ts). */
export const SUBSCRIBER_SLOTS_CAPABILITY = 'subscriber_slots';

const ILIMO_CAPABILITIES_FIELD = 100;

/**
 * Returns a copy of `msg` with `capabilities` appended as field 100 (repeated string) — safe to
 * embed in a parent message afterwards, since the extra field travels with it.
 */
export function withIlimoCapabilities<T extends Message<T>>(msg: T, capabilities: string[]): T {
  const bytes = msg.toBinary();
  const writer = new BinaryWriter();
  for (const capability of capabilities) {
    writer.tag(ILIMO_CAPABILITIES_FIELD, WireType.LengthDelimited).string(capability);
  }
  const extra = writer.finish();
  const combined = new Uint8Array(bytes.length + extra.length);
  combined.set(bytes, 0);
  combined.set(extra, bytes.length);
  return (msg.constructor as unknown as { fromBinary(bytes: Uint8Array): T }).fromBinary(combined);
}

/** Reads back every ilimo_capabilities entry (field 100) from `msg`, in wire order. */
export function readIlimoCapabilities(msg: Message): string[] {
  const bytes = msg.toBinary();
  const reader = new BinaryReader(bytes);
  const capabilities: string[] = [];
  while (reader.pos < bytes.length) {
    const [fieldNo, wireType] = reader.tag();
    if (fieldNo === ILIMO_CAPABILITIES_FIELD && wireType === WireType.LengthDelimited) {
      capabilities.push(reader.string());
    } else {
      reader.skip(wireType, fieldNo);
    }
  }
  return capabilities;
}
