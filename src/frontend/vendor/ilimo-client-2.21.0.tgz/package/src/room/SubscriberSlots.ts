// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// ilimo's `subscriber_slots` behind the LiveKit API: every subscribed remote track gets its
// RemoteTrack at once, playing a silent placeholder, so the UI attaches it and adaptiveStream
// reports its visibility; the server then says which slot section carries which track, and the
// slot's MediaStreamTrack moves into that RemoteTrack. See api/ilimoSlots.ts.
import type { IlimoSlot } from '../api/ilimoSlots';
import type RemoteTrack from './track/RemoteTrack';

/** How long a video slot waits for the new track's first frame before showing it anyway. */
const FIRST_FRAME_WAIT_MS = 1000;

/** How often a video slot checks for that frame. A timer rather than requestAnimationFrame,
 * which never fires in a hidden tab. */
const FIRST_FRAME_POLL_MS = 15;

export interface SlotHost {
  /** The RemoteTrack of `trackSid`, published by `participantSid`, if it exists yet. */
  remoteTrack(participantSid: string, trackSid: string): RemoteTrack | undefined;
}

interface Section {
  track: MediaStreamTrack;
  receiver: RTCRtpReceiver;
}

export class SubscriberSlots {
  private sections = new Map<string, Section>();

  /** The latest entry received for each slot. */
  private slots = new Map<string, IlimoSlot>();

  /** The RemoteTrack each slot currently plays in. */
  private shown = new Map<string, RemoteTrack>();

  /** The placeholder of each RemoteTrack, played while no slot carries it. */
  private placeholders = new WeakMap<RemoteTrack, MediaStreamTrack>();

  /** Bumped on each change of a slot: a pending switch checks it is still current. */
  private versions = new Map<string, number>();

  constructor(
    private host: SlotHost,
    private nextFrame: (callback: () => void) => void = (callback) =>
      setTimeout(callback, FIRST_FRAME_POLL_MS),
    private now: () => number = () => performance.now(),
  ) {}

  /** A remote track was just created on `placeholder`. */
  addPlaceholder(track: RemoteTrack, placeholder: MediaStreamTrack) {
    this.placeholders.set(track, placeholder);
    for (const [mid, slot] of this.slots) {
      if (slot.trackSid === track.sid) {
        this.apply(mid);
      }
    }
  }

  /** The receive section of slot `mid` arrived. */
  addSection(mid: string, track: MediaStreamTrack, receiver: RTCRtpReceiver) {
    this.sections.set(mid, { track, receiver });
    this.apply(mid);
  }

  update(slots: IlimoSlot[]) {
    for (const slot of slots) {
      this.slots.set(slot.mid, slot);
      this.apply(slot.mid);
    }
  }

  /** `track` is gone: no slot plays in it any more. */
  removeTrack(track: RemoteTrack) {
    for (const [mid, shown] of this.shown) {
      if (shown === track) {
        this.shown.delete(mid);
      }
    }
  }

  private apply(mid: string) {
    const version = (this.versions.get(mid) ?? 0) + 1;
    this.versions.set(mid, version);
    const slot = this.slots.get(mid);
    const section = this.sections.get(mid);
    const next = slot?.trackSid
      ? this.host.remoteTrack(slot.participantSid, slot.trackSid)
      : undefined;
    const previous = this.shown.get(mid);
    if (previous && previous !== next) {
      this.shown.delete(mid);
      this.restorePlaceholder(previous, section);
    }
    if (!slot || !section || !next) {
      return;
    }
    const show = () => {
      if (this.versions.get(mid) !== version) {
        return;
      }
      for (const [otherMid, shown] of this.shown) {
        if (shown === next && otherMid !== mid) {
          this.shown.delete(otherMid);
        }
      }
      next.switchMediaStreamTrack(section.track, section.receiver);
      this.shown.set(mid, next);
    };
    if (section.track.kind === 'audio') {
      show();
      return;
    }
    const deadline = this.now() + FIRST_FRAME_WAIT_MS;
    const wait = () => {
      if (this.versions.get(mid) !== version) {
        return;
      }
      if (reached(section.receiver, slot.rtpTimestamp) || this.now() > deadline) {
        show();
      } else {
        this.nextFrame(wait);
      }
    };
    wait();
  }

  private restorePlaceholder(track: RemoteTrack, section: Section | undefined) {
    const placeholder = this.placeholders.get(track);
    if (placeholder && (!section || track.mediaStreamTrack === section.track)) {
      track.switchMediaStreamTrack(placeholder, undefined);
    }
  }
}

/**
 * Whether `receiver` delivered a frame at RTP timestamp `target` or after (modulo 2^32). True
 * when the browser does not report RTP timestamps.
 */
function reached(receiver: RTCRtpReceiver, target: number): boolean {
  const source = receiver.getSynchronizationSources?.()[0];
  if (!source) {
    return false;
  }
  if (source.rtpTimestamp === undefined) {
    return true;
  }
  return (source.rtpTimestamp - target) >>> 0 < 0x80000000;
}
