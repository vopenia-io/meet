// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
// ilimo's `subscriber_slots` behind the LiveKit API: every subscribed remote track gets its
// RemoteTrack at once, playing a silent placeholder, so the UI attaches it and adaptiveStream
// reports its visibility; the server then says which slot section carries which track, and the
// slot's MediaStreamTrack moves into that RemoteTrack. See api/ilimoSlots.ts.
import type { IlimoSlot } from '../api/ilimoSlots';
import type RemoteTrack from './track/RemoteTrack';

/** How long a video slot waits for the new track's first frame before showing it anyway. */
const FIRST_FRAME_WAIT_MS = 1000;

/** How often a video slot checks for that frame. A timer rather than requestAnimationFrame,
 * which never fires in a hidden tab. */
const FIRST_FRAME_POLL_MS = 15;

export interface SlotHost {
  /** The RemoteTrack of `trackSid`, published by `participantSid`, if it exists yet. */
  remoteTrack(participantSid: string, trackSid: string): RemoteTrack | undefined;
}

interface Section {
  track: MediaStreamTrack;
  receiver: RTCRtpReceiver;
}

export class SubscriberSlots {
  private sections = new Map<string, Section>();

  /** The latest entry received for each slot. */
  private slots = new Map<string, IlimoSlot>();

  /** The RemoteTrack each slot currently plays in. */
  private shown = new Map<string, RemoteTrack>();

  /** The placeholder of each RemoteTrack, played while no slot carries it. */
  private placeholders = new WeakMap<RemoteTrack, MediaStreamTrack>();

  /** Bumped on each change of a slot: a pending switch checks it is still current. */
  private versions = new Map<string, number>();

  /** The RemoteTracks still playing a section of the connection being left (see handover). */
  private lingering = new Set<RemoteTrack>();

  constructor(
    private host: SlotHost,
    private nextFrame: (callback: () => void) => void = (callback) =>
      setTimeout(callback, FIRST_FRAME_POLL_MS),
    private now: () => number = () => performance.now(),
  ) {}

  /** A remote track was just created on `placeholder`. */
  addPlaceholder(track: RemoteTrack, placeholder: MediaStreamTrack) {
    this.placeholders.set(track, placeholder);
    for (const [mid, slot] of this.slots) {
      if (slot.trackSid === track.sid) {
        this.apply(mid);
      }
    }
  }

  /** The receive section of slot `mid` arrived. */
  addSection(mid: string, track: MediaStreamTrack, receiver: RTCRtpReceiver) {
    this.sections.set(mid, { track, receiver });
    this.apply(mid);
  }

  update(slots: IlimoSlot[]) {
    for (const slot of slots) {
      this.slots.set(slot.mid, slot);
      this.apply(slot.mid);
    }
  }

  /**
   * The participant moves to another node: the sections and slots to come are the next
   * connection's. Each RemoteTrack keeps playing the section it is in, of the connection being
   * left, until a slot of the next one carries it or {@link retireLingering} is called.
   */
  handover() {
    for (const mid of new Set([...this.sections.keys(), ...this.slots.keys()])) {
      this.versions.set(mid, (this.versions.get(mid) ?? 0) + 1);
    }
    for (const track of this.shown.values()) {
      this.lingering.add(track);
    }
    this.shown.clear();
    this.sections.clear();
    this.slots.clear();
  }

  /** Whether no RemoteTrack still plays a section of the connection being left: the next one
   * carries each of them. */
  get settled(): boolean {
    return this.lingering.size === 0;
  }

  /** The connection being left is closing: what still plays one of its sections goes back to
   * its placeholder. */
  retireLingering() {
    for (const track of this.lingering) {
      const placeholder = this.placeholders.get(track);
      if (placeholder) {
        track.switchMediaStreamTrack(placeholder, undefined);
      }
    }
    this.lingering.clear();
  }

  /** `track` is gone: no slot plays in it any more. */
  removeTrack(track: RemoteTrack) {
    this.lingering.delete(track);
    for (const [mid, shown] of this.shown) {
      if (shown === track) {
        this.shown.delete(mid);
      }
    }
  }

  private apply(mid: string) {
    const version = (this.versions.get(mid) ?? 0) + 1;
    this.versions.set(mid, version);
    const slot = this.slots.get(mid);
    const section = this.sections.get(mid);
    const next = slot?.trackSid
      ? this.host.remoteTrack(slot.participantSid, slot.trackSid)
      : undefined;
    const previous = this.shown.get(mid);
    if (previous && previous !== next) {
      this.shown.delete(mid);
      this.restorePlaceholder(previous, section);
    }
    if (!slot || !section || !next) {
      return;
    }
    const show = () => {
      if (this.versions.get(mid) !== version) {
        return;
      }
      for (const [otherMid, shown] of this.shown) {
        if (shown === next && otherMid !== mid) {
          this.shown.delete(otherMid);
        }
      }
      next.switchMediaStreamTrack(section.track, section.receiver);
      this.shown.set(mid, next);
      this.lingering.delete(next);
    };
    if (section.track.kind === 'audio') {
      show();
      return;
    }
    const deadline = this.now() + FIRST_FRAME_WAIT_MS;
    const wait = () => {
      if (this.versions.get(mid) !== version) {
        return;
      }
      // A track still playing a section of the connection being left waits for the frame
      // however long: that section shows the picture meanwhile.
      const overdue = this.now() > deadline && !this.lingering.has(next);
      if (reached(section.receiver, slot.rtpTimestamp) || overdue) {
        show();
      } else {
        this.nextFrame(wait);
      }
    };
    wait();
  }

  private restorePlaceholder(track: RemoteTrack, section: Section | undefined) {
    const placeholder = this.placeholders.get(track);
    if (placeholder && (!section || track.mediaStreamTrack === section.track)) {
      track.switchMediaStreamTrack(placeholder, undefined);
    }
  }
}

/**
 * Whether `receiver` delivered a frame at RTP timestamp `target` or after (modulo 2^32). True
 * when the browser does not report RTP timestamps.
 */
function reached(receiver: RTCRtpReceiver, target: number): boolean {
  const source = receiver.getSynchronizationSources?.()[0];
  if (!source) {
    return false;
  }
  if (source.rtpTimestamp === undefined) {
    return true;
  }
  return (source.rtpTimestamp - target) >>> 0 < 0x80000000;
}
