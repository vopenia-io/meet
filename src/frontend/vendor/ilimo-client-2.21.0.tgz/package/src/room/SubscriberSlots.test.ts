// SPDX-License-Identifier: Apache-2.0 OR MIT
// Copyright 2026 Vopenia
import { describe, expect, it } from 'vitest';
import { SubscriberSlots } from './SubscriberSlots';
import type RemoteTrack from './track/RemoteTrack';

function mediaTrack(kind: 'audio' | 'video', id: string) {
  return { kind, id } as MediaStreamTrack;
}

function remoteTrack(sid: string, placeholder: MediaStreamTrack) {
  const track = {
    sid,
    mediaStreamTrack: placeholder,
    switchMediaStreamTrack(next: MediaStreamTrack) {
      track.mediaStreamTrack = next;
    },
  };
  return track as unknown as RemoteTrack;
}

function receiver(rtpTimestamp: () => number | undefined) {
  return {
    getSynchronizationSources: () => [{ rtpTimestamp: rtpTimestamp() }],
  } as unknown as RTCRtpReceiver;
}

function setup() {
  const tracks = new Map<string, RemoteTrack>();
  const frames: Array<() => void> = [];
  let now = 0;
  const slots = new SubscriberSlots(
    { remoteTrack: (_, trackSid) => tracks.get(trackSid) },
    (callback) => frames.push(callback),
    () => now,
  );
  const add = (sid: string, kind: 'audio' | 'video') => {
    const placeholder = mediaTrack(kind, `placeholder-${sid}`);
    const track = remoteTrack(sid, placeholder);
    tracks.set(sid, track);
    slots.addPlaceholder(track, placeholder);
    return { track, placeholder };
  };
  const runFrames = (ms: number) => {
    now += ms;
    frames.splice(0).forEach((frame) => frame());
  };
  return { slots, add, runFrames };
}

describe('SubscriberSlots', () => {
  it('plays an audio slot in its track once both are known, whatever the order', () => {
    const { slots, add } = setup();
    const section = mediaTrack('audio', 'slot-a');
    slots.update([{ mid: 'a', participantSid: 'PA_1', trackSid: 'TR_1', rtpTimestamp: 0 }]);
    slots.addSection(
      'a',
      section,
      receiver(() => undefined),
    );
    const { track } = add('TR_1', 'audio');
    expect(track.mediaStreamTrack).toBe(section);
  });

  it('switches a video slot on the first frame of its new track', () => {
    const { slots, add, runFrames } = setup();
    const first = add('TR_1', 'video');
    const second = add('TR_2', 'video');
    let delivered = 1_000;
    const section = mediaTrack('video', 'slot-v');
    slots.addSection(
      'v',
      section,
      receiver(() => delivered),
    );
    slots.update([{ mid: 'v', participantSid: 'PA_1', trackSid: 'TR_1', rtpTimestamp: 1_000 }]);
    expect(first.track.mediaStreamTrack).toBe(section);

    slots.update([{ mid: 'v', participantSid: 'PA_2', trackSid: 'TR_2', rtpTimestamp: 50_000 }]);
    expect(first.track.mediaStreamTrack).toBe(first.placeholder);
    expect(second.track.mediaStreamTrack).toBe(second.placeholder);
    runFrames(16);
    expect(second.track.mediaStreamTrack).toBe(second.placeholder);
    delivered = 50_000;
    runFrames(16);
    expect(second.track.mediaStreamTrack).toBe(section);
  });

  it('shows a video slot after a second without its first frame', () => {
    const { slots, add, runFrames } = setup();
    const { track } = add('TR_1', 'video');
    const section = mediaTrack('video', 'slot-v');
    slots.addSection(
      'v',
      section,
      receiver(() => 10),
    );
    slots.update([{ mid: 'v', participantSid: 'PA_1', trackSid: 'TR_1', rtpTimestamp: 20 }]);
    runFrames(500);
    expect(track.mediaStreamTrack).not.toBe(section);
    runFrames(600);
    expect(track.mediaStreamTrack).toBe(section);
  });

  it('compares RTP timestamps across their wrap', () => {
    const { slots, add } = setup();
    const { track } = add('TR_1', 'video');
    const section = mediaTrack('video', 'slot-v');
    slots.addSection(
      'v',
      section,
      receiver(() => 5),
    );
    slots.update([
      { mid: 'v', participantSid: 'PA_1', trackSid: 'TR_1', rtpTimestamp: 4_294_967_290 },
    ]);
    expect(track.mediaStreamTrack).toBe(section);
  });

  it('keeps a track that moved to another slot when its old slot empties', () => {
    const { slots, add } = setup();
    const { track } = add('TR_1', 'audio');
    const a = mediaTrack('audio', 'slot-a');
    const b = mediaTrack('audio', 'slot-b');
    slots.addSection(
      'a',
      a,
      receiver(() => undefined),
    );
    slots.addSection(
      'b',
      b,
      receiver(() => undefined),
    );
    slots.update([{ mid: 'a', participantSid: 'PA_1', trackSid: 'TR_1', rtpTimestamp: 0 }]);
    slots.update([{ mid: 'b', participantSid: 'PA_1', trackSid: 'TR_1', rtpTimestamp: 0 }]);
    slots.update([{ mid: 'a', participantSid: '', trackSid: '', rtpTimestamp: 0 }]);
    expect(track.mediaStreamTrack).toBe(b);
  });
});
