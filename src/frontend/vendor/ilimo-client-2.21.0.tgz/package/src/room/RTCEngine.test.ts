import {
  DataPacket,
  DataPacket_Kind,
  DisconnectReason,
  ReconnectReason,
  UserPacket,
} from '@livekit/protocol';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { SignalConnectionState } from '../api/SignalClient';
import type { DataPacketBuffer } from '../utils/dataPacketBuffer';
import { PCTransportState } from './PCTransportManager';
import RTCEngine, { DataChannelKind } from './RTCEngine';
import { roomOptionDefaults } from './defaults';
import { ConnectionError, PublishDataError, UnexpectedConnectionState } from './errors';

describe('RTCEngine', () => {
  const originalRTCRtpSender = window.RTCRtpSender;
  const originalRTCRtpScriptTransform = (window as unknown as { RTCRtpScriptTransform?: unknown })
    .RTCRtpScriptTransform;
  const originalUserAgent = navigator.userAgent;

  afterEach(() => {
    Object.defineProperty(window, 'RTCRtpSender', {
      configurable: true,
      value: originalRTCRtpSender,
      writable: true,
    });
    Object.defineProperty(window, 'RTCRtpScriptTransform', {
      configurable: true,
      value: originalRTCRtpScriptTransform,
      writable: true,
    });
    Object.defineProperty(window.navigator, 'userAgent', {
      configurable: true,
      value: originalUserAgent,
    });
  });

  function stubInsertableStreamsSupport() {
    class MockRTCRtpSender {
      createEncodedStreams() {}
    }

    Object.defineProperty(window, 'RTCRtpSender', {
      configurable: true,
      value: MockRTCRtpSender,
      writable: true,
    });
  }

  function stubScriptTransformSupport() {
    Object.defineProperty(window, 'RTCRtpScriptTransform', {
      configurable: true,
      value: class MockRTCRtpScriptTransform {},
      writable: true,
    });
    Object.defineProperty(window.navigator, 'userAgent', {
      configurable: true,
      value:
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
    });
  }

  function makeRTCConfiguration(engine: RTCEngine) {
    return (
      engine as unknown as { makeRTCConfiguration: () => RTCConfiguration }
    ).makeRTCConfiguration();
  }

  function setupFrameMetadataSender(engine: RTCEngine, sender: RTCRtpSender, opts = {}) {
    (
      engine as unknown as {
        setupFrameMetadataSender: (sender: RTCRtpSender, opts?: unknown) => void;
      }
    ).setupFrameMetadataSender(sender, opts);
  }

  it('does not enable encoded insertable streams without E2EE or a packet trailer worker', () => {
    stubInsertableStreamsSupport();

    const engine = new RTCEngine(roomOptionDefaults);

    expect(makeRTCConfiguration(engine).encodedInsertableStreams).toBeUndefined();
  });

  it('enables encoded insertable streams when a packet trailer worker is configured', () => {
    stubInsertableStreamsSupport();

    const engine = new RTCEngine({
      ...roomOptionDefaults,
      packetTrailer: { worker: {} as Worker },
    });

    expect(makeRTCConfiguration(engine).encodedInsertableStreams).toBe(true);
  });

  it('does not enable encoded insertable streams for packet trailers when script transforms are supported', () => {
    stubInsertableStreamsSupport();
    stubScriptTransformSupport();

    const engine = new RTCEngine({
      ...roomOptionDefaults,
      packetTrailer: { worker: {} as Worker },
    });

    expect(makeRTCConfiguration(engine).encodedInsertableStreams).toBeUndefined();
  });

  it('enables encoded insertable streams for E2EE', () => {
    stubInsertableStreamsSupport();

    const engine = new RTCEngine(roomOptionDefaults);
    (
      engine as unknown as {
        signalOpts: {
          autoSubscribe: boolean;
          maxRetries: number;
          e2eeEnabled: boolean;
          websocketTimeout: number;
        };
      }
    ).signalOpts = {
      autoSubscribe: true,
      maxRetries: 1,
      e2eeEnabled: true,
      websocketTimeout: 15_000,
    };

    expect(makeRTCConfiguration(engine).encodedInsertableStreams).toBe(true);
  });

  it('does not create sender encoded streams when packetTrailer has no worker', () => {
    const engine = new RTCEngine({
      ...roomOptionDefaults,
      packetTrailer: {} as never,
    });
    const createEncodedStreams = vi.fn();
    const sender = {
      createEncodedStreams,
    } as unknown as RTCRtpSender;

    setupFrameMetadataSender(engine, sender);

    expect(createEncodedStreams).not.toHaveBeenCalled();
  });

  it('does not create sender passthrough streams for packet trailers when script transforms are supported', () => {
    stubScriptTransformSupport();

    const engine = new RTCEngine({
      ...roomOptionDefaults,
      packetTrailer: { worker: {} as Worker },
    });
    const createEncodedStreams = vi.fn();
    const sender = {
      createEncodedStreams,
    } as unknown as RTCRtpSender;

    setupFrameMetadataSender(engine, sender);

    expect(createEncodedStreams).not.toHaveBeenCalled();
  });

  it('posts sender encode streams to the packet trailer worker when write features are enabled', () => {
    stubInsertableStreamsSupport();

    const worker = { postMessage: vi.fn() } as unknown as Worker;
    const engine = new RTCEngine({
      ...roomOptionDefaults,
      packetTrailer: { worker },
    });
    const readable = {} as ReadableStream;
    const writable = {} as WritableStream;
    const createEncodedStreams = vi.fn(() => ({ readable, writable }));
    const sender = {
      createEncodedStreams,
    } as unknown as RTCRtpSender;

    setupFrameMetadataSender(engine, sender, { packetTrailer: { timestamp: true, frameId: true } });

    expect(createEncodedStreams).toHaveBeenCalledTimes(1);
    expect(worker.postMessage).toHaveBeenCalledWith(
      {
        kind: 'encode',
        data: {
          readableStream: readable,
          writableStream: writable,
          packetTrailer: { timestamp: true, frameId: true },
        },
      },
      [readable, writable],
    );
  });

  it('uses RTCRtpScriptTransform for sender packet trailer writes when supported', () => {
    stubScriptTransformSupport();

    const transform = {};
    const RTCRtpScriptTransform = vi.fn(function () {
      return transform;
    });
    Object.defineProperty(window, 'RTCRtpScriptTransform', {
      configurable: true,
      value: RTCRtpScriptTransform,
      writable: true,
    });
    Object.defineProperty(globalThis, 'RTCRtpScriptTransform', {
      configurable: true,
      value: RTCRtpScriptTransform,
      writable: true,
    });

    const worker = {} as Worker;
    const engine = new RTCEngine({
      ...roomOptionDefaults,
      packetTrailer: { worker },
    });
    const createEncodedStreams = vi.fn();
    const sender = {
      createEncodedStreams,
    } as unknown as RTCRtpSender;

    setupFrameMetadataSender(engine, sender, { packetTrailer: { timestamp: true } });

    expect(RTCRtpScriptTransform).toHaveBeenCalledWith(worker, {
      kind: 'encode',
      packetTrailer: { timestamp: true },
    });
    expect((sender as unknown as { transform: unknown }).transform).toBe(transform);
    expect(createEncodedStreams).not.toHaveBeenCalled();
  });

  describe('verifyTransport', () => {
    function stubTransport(engine: RTCEngine, onDataChannel: boolean) {
      Object.assign(engine as unknown as Record<string, unknown>, {
        pcManager: { currentState: PCTransportState.CONNECTED },
      });
      Object.assign(engine.client as unknown as Record<string, unknown>, {
        ws: undefined,
      });
      Object.defineProperty(engine.client, 'isOnDataChannel', { get: () => onDataChannel });
    }

    it('counts ilimo _signal as a connected signal transport', () => {
      const engine = new RTCEngine(roomOptionDefaults);
      stubTransport(engine, true);
      expect(engine.verifyTransport()).toBe(true);
    });

    it('needs the WebSocket when signaling is not on _signal', () => {
      const engine = new RTCEngine(roomOptionDefaults);
      stubTransport(engine, false);
      expect(engine.verifyTransport()).toBe(false);
    });
  });

  describe('resumeConnection', () => {
    it('moves back to _signal when the peer connection stayed connected', async () => {
      vi.useFakeTimers();
      try {
        const engine = new RTCEngine({
          ...roomOptionDefaults,
          singlePeerConnection: true,
          signalOverDataChannel: true,
        });
        const signalDataChannel = { readyState: 'open' } as RTCDataChannel;
        Object.assign(engine as unknown as Record<string, unknown>, {
          url: 'ws://ilimo',
          token: 'token',
          signalDataChannel,
          pcManager: {
            currentState: PCTransportState.CONNECTED,
            updateConfiguration: vi.fn(),
            triggerIceRestart: vi.fn().mockResolvedValue(undefined),
            ensurePCTransportConnection: vi.fn().mockResolvedValue(undefined),
          },
        });
        const switchToDataChannel = vi.fn().mockReturnValue(true);
        Object.assign(engine.client as unknown as Record<string, unknown>, {
          reconnect: vi.fn().mockResolvedValue(undefined),
          setReconnected: vi.fn(),
          switchToDataChannel,
        });
        Object.defineProperty(engine.client, 'currentState', {
          get: () => SignalConnectionState.CONNECTED,
        });

        const resumed = (
          engine as unknown as { resumeConnection: () => Promise<void> }
        ).resumeConnection();
        await vi.runAllTimersAsync();
        await resumed;

        expect(switchToDataChannel).toHaveBeenCalledWith(signalDataChannel);
      } finally {
        vi.useRealTimers();
      }
    });
  });

  describe('a resume refused', () => {
    type ReconnectInternals = {
      attemptReconnect: (reason?: ReconnectReason) => Promise<void>;
      resumeConnection: (reason?: ReconnectReason) => Promise<void>;
      restartConnection: () => Promise<void>;
    };

    function stubRecovery(resumeError: Error) {
      const engine = new RTCEngine(roomOptionDefaults);
      Object.assign(engine as unknown as Record<string, unknown>, {
        pcManager: { currentState: PCTransportState.CONNECTED },
        _isClosed: false,
      });
      const internals = engine as unknown as ReconnectInternals;
      const resume = vi.spyOn(internals, 'resumeConnection').mockRejectedValue(resumeError);
      const restart = vi.spyOn(internals, 'restartConnection').mockResolvedValue();
      return { internals, resume, restart };
    }

    it('joins again at once when the resume gets a Leave, its node being lost', async () => {
      vi.useFakeTimers();
      try {
        const { internals, resume, restart } = stubRecovery(
          ConnectionError.leaveRequest(
            'Received leave request while trying to (re)connect',
            DisconnectReason.STATE_MISMATCH,
          ),
        );
        await internals.attemptReconnect(ReconnectReason.RR_SIGNAL_DISCONNECTED);
        expect(resume).toHaveBeenCalledTimes(1);
        await vi.advanceTimersByTimeAsync(0);
        expect(restart).toHaveBeenCalledTimes(1);
      } finally {
        vi.useRealTimers();
      }
    });

    it('waits for the next delay of its policy after any other failure', async () => {
      vi.useFakeTimers();
      try {
        const { internals, restart } = stubRecovery(new Error('the node did not answer'));
        await internals.attemptReconnect(ReconnectReason.RR_SIGNAL_DISCONNECTED);
        await vi.advanceTimersByTimeAsync(0);
        expect(restart).not.toHaveBeenCalled();
        await vi.advanceTimersByTimeAsync(300);
        expect(restart).toHaveBeenCalledTimes(1);
      } finally {
        vi.useRealTimers();
      }
    });
  });

  describe('path changes under _signal', () => {
    type EngineInternals = {
      handlePublisherConnectionState: (state: RTCPeerConnectionState) => void;
      attemptReconnect: (reason?: ReconnectReason) => Promise<void>;
      registerOnLineListener: () => void;
      deregisterOnLineListener: () => void;
    };

    function stubConnectedOnSignal(engine: RTCEngine, onDataChannel = true) {
      const publisher = { state: 'connected' as RTCPeerConnectionState };
      const triggerIceRestart = vi.fn().mockResolvedValue(undefined);
      Object.assign(engine as unknown as Record<string, unknown>, {
        pcManager: {
          currentState: PCTransportState.CONNECTED,
          publisher: { getConnectionState: () => publisher.state },
          triggerIceRestart,
        },
        // PCState.Connected
        pcState: 1,
        _isClosed: false,
      });
      Object.defineProperty(engine.client, 'isOnDataChannel', { get: () => onDataChannel });
      const internals = engine as unknown as EngineInternals;
      const attemptReconnect = vi.spyOn(internals, 'attemptReconnect').mockResolvedValue();
      const setPublisherState = (state: RTCPeerConnectionState) => {
        publisher.state = state;
        internals.handlePublisherConnectionState(state);
      };
      return { attemptReconnect, triggerIceRestart, setPublisherState, internals };
    }

    it('resumes in under 3 s once the connection _signal rides is disconnected', async () => {
      vi.useFakeTimers();
      try {
        const engine = new RTCEngine(roomOptionDefaults);
        const { attemptReconnect, setPublisherState } = stubConnectedOnSignal(engine);
        setPublisherState('disconnected');
        await vi.advanceTimersByTimeAsync(1000);
        expect(attemptReconnect).toHaveBeenCalledTimes(1);
        expect(attemptReconnect).toHaveBeenCalledWith(ReconnectReason.RR_PUBLISHER_FAILED);
      } finally {
        vi.useRealTimers();
      }
    });

    it('stays on _signal when the connection comes back first', async () => {
      vi.useFakeTimers();
      try {
        const engine = new RTCEngine(roomOptionDefaults);
        const { attemptReconnect, setPublisherState } = stubConnectedOnSignal(engine);
        setPublisherState('disconnected');
        await vi.advanceTimersByTimeAsync(200);
        setPublisherState('connected');
        await vi.advanceTimersByTimeAsync(5000);
        expect(attemptReconnect).not.toHaveBeenCalled();
      } finally {
        vi.useRealTimers();
      }
    });

    it('leaves a disconnected connection to ICE while signaling on the WebSocket', async () => {
      vi.useFakeTimers();
      try {
        const engine = new RTCEngine(roomOptionDefaults);
        const { attemptReconnect, setPublisherState } = stubConnectedOnSignal(engine, false);
        setPublisherState('disconnected');
        await vi.advanceTimersByTimeAsync(5000);
        expect(attemptReconnect).not.toHaveBeenCalled();
      } finally {
        vi.useRealTimers();
      }
    });

    it('restarts ICE over _signal when the network changes, not when its estimates do', () => {
      const connection = Object.assign(new EventTarget(), { type: 'wifi' });
      Object.defineProperty(window.navigator, 'connection', {
        configurable: true,
        value: connection,
      });
      try {
        const engine = new RTCEngine(roomOptionDefaults);
        const { triggerIceRestart, attemptReconnect, internals } = stubConnectedOnSignal(engine);
        internals.registerOnLineListener();
        connection.dispatchEvent(new Event('change'));
        expect(triggerIceRestart).not.toHaveBeenCalled();

        connection.type = 'cellular';
        connection.dispatchEvent(new Event('change'));
        expect(triggerIceRestart).toHaveBeenCalledTimes(1);
        expect(attemptReconnect).not.toHaveBeenCalled();
        internals.deregisterOnLineListener();
      } finally {
        delete (window.navigator as unknown as { connection?: unknown }).connection;
      }
    });
  });

  describe('sendDataPacket', () => {
    const MAX_DATA_PACKET_SIZE = 64 * 1024 - 1; // 65535 bytes (64 KB - 1)
    function stubConnectedEngine(
      engine: RTCEngine,
      maxDataPacketSize: number = MAX_DATA_PACKET_SIZE,
    ) {
      const dc = new FakeDataChannel();
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: false,
        ensurePublisherConnected: vi.fn().mockResolvedValue(undefined),
        pcManager: {
          getMaxPublisherMessageSize: vi.fn(() => maxDataPacketSize),
        },
      });
      attachFakeChannel(engine, 'reliableChannel', dc);
      return dc.send;
    }

    it('rejects packets larger than the max data packet size', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const send = stubConnectedEngine(engine);

      // The serialized packet includes protobuf framing on top of the payload, so a payload at the
      // limit is already guaranteed to exceed it once serialized.
      const packet = new DataPacket({
        kind: DataPacket_Kind.RELIABLE,
        value: {
          case: 'user',
          value: new UserPacket({ payload: new Uint8Array(MAX_DATA_PACKET_SIZE) }),
        },
      });

      await expect(engine.sendDataPacket(packet, DataChannelKind.RELIABLE)).rejects.toBeInstanceOf(
        PublishDataError,
      );
      expect(send).not.toHaveBeenCalled();
    });

    it('does not reject packets if the max data packet size is 0', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const send = stubConnectedEngine(engine, 0);

      const packet = new DataPacket({
        kind: DataPacket_Kind.RELIABLE,
        value: {
          case: 'user',
          value: new UserPacket({ payload: new Uint8Array(100) }),
        },
      });

      // Sending the packet should succeed, there isn't a size limit
      await expect(
        engine.sendDataPacket(packet, DataChannelKind.RELIABLE),
      ).resolves.toBeUndefined();
      expect(send).toHaveBeenCalledTimes(1);
    });

    it('sends packets within the max data packet size', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const send = stubConnectedEngine(engine);

      const packet = new DataPacket({
        kind: DataPacket_Kind.RELIABLE,
        value: {
          case: 'user',
          value: new UserPacket({ payload: new Uint8Array(1024) }),
        },
      });

      await expect(
        engine.sendDataPacket(packet, DataChannelKind.RELIABLE),
      ).resolves.toBeUndefined();
      expect(send).toHaveBeenCalledTimes(1);
    });
  });

  class FakeDataChannel extends EventTarget {
    bufferedAmount = 0;

    bufferedAmountLowThreshold = 64 * 1024;

    send = vi.fn();
  }

  const tick = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

  /** The reliable channel's private replay buffer — reached through casts, as tests do for engine privates. */
  const reliableBuffer = (engine: RTCEngine) =>
    (engine as unknown as { reliableChannel: { messageBuffer: DataPacketBuffer } }).reliableChannel
      .messageBuffer;

  type ChannelField = 'reliableChannel' | 'lossyChannel' | 'dataTrackChannel';
  const engineChannel = (engine: RTCEngine, field: ChannelField) =>
    (
      engine as unknown as Record<
        ChannelField,
        { attach(dc: RTCDataChannel): void; invalidateWaiters(reason: string): void }
      >
    )[field];
  /** Attach a fake handle to one of the engine's flow-control wrappers. */
  const attachFakeChannel = (engine: RTCEngine, field: ChannelField, dc: FakeDataChannel) =>
    engineChannel(engine, field).attach(dc as unknown as RTCDataChannel);

  describe('resendReliableMessagesForResume', () => {
    it('does not let a concurrent reliable send interleave into the resume replay', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: false,
        ensurePublisherConnected: vi.fn().mockResolvedValue(undefined),
        pcManager: {
          getMaxPublisherMessageSize: vi.fn(() => 64 * 1024 - 1),
        },
      });
      attachFakeChannel(engine, 'reliableChannel', dc);

      // Two messages queued for replay, and a full buffer so the replay parks on
      // waitForBufferHeadroom before its first send.
      const replayed1 = new Uint8Array([1]);
      const replayed2 = new Uint8Array([2]);
      const buffer = reliableBuffer(engine);
      buffer.push({ data: replayed1, sequence: 1, sent: true });
      buffer.push({ data: replayed2, sequence: 2, sent: true });
      dc.bufferedAmount = 2 * 1024 * 1024; // above the reliable high-water mark

      const replay = (
        engine as unknown as { resendReliableMessagesForResume: (seq: number) => Promise<void> }
      ).resendReliableMessagesForResume(0);
      await tick();

      // A send racing the replay: its sequence is assigned immediately, but it must not hit the
      // wire before the replayed (lower-sequence) messages, or receivers discard those as dupes.
      const concurrentSend = engine.sendDataPacket(
        new DataPacket({
          kind: DataPacket_Kind.RELIABLE,
          value: { case: 'user', value: new UserPacket({ payload: new Uint8Array([3]) }) },
        }),
        DataChannelKind.RELIABLE,
      );
      await tick();

      // Buffer drains: the replay must finish its whole batch before the concurrent send.
      dc.bufferedAmount = 0;
      dc.dispatchEvent(new Event('bufferedamountlow'));
      await Promise.all([replay, concurrentSend]);

      expect(dc.send).toHaveBeenCalledTimes(3);
      expect(dc.send.mock.calls[0][0]).toBe(replayed1);
      expect(dc.send.mock.calls[1][0]).toBe(replayed2);
      expect(dc.send.mock.calls[2][0]).not.toBe(replayed1);
      expect(dc.send.mock.calls[2][0]).not.toBe(replayed2);
    });
  });

  describe('reliable sends during teardown windows', () => {
    const makePacket = (byte: number) =>
      new DataPacket({
        kind: DataPacket_Kind.RELIABLE,
        value: { case: 'user', value: new UserPacket({ payload: new Uint8Array([byte]) }) },
      });

    function stubEngine(engine: RTCEngine, dc: FakeDataChannel) {
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: false,
        ensurePublisherConnected: vi.fn().mockResolvedValue(undefined),
        pcManager: {
          getMaxPublisherMessageSize: vi.fn(() => 64 * 1024 - 1),
        },
      });
      attachFakeChannel(engine, 'reliableChannel', dc);
      return reliableBuffer(engine);
    }

    it('resolves and queues the packet for replay when the wait is torn down transiently', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      const buffer = stubEngine(engine, dc);

      // Park the send on a full buffer, then invalidate the channel (reconnect/replacement).
      dc.bufferedAmount = 2 * 1024 * 1024;
      const send = engine.sendDataPacket(makePacket(1), DataChannelKind.RELIABLE);
      await tick();
      engineChannel(engine, 'reliableChannel').invalidateWaiters('data channels recreated');

      // The send must not surface the teardown — the packet is queued for the resume replay.
      await expect(send).resolves.toBeUndefined();
      expect(dc.send).not.toHaveBeenCalled();
      expect(buffer.length).toBe(1);
      expect(buffer.getAll()[0].sent).toBe(false);

      // The replay then delivers it.
      dc.bufferedAmount = 0;
      await (
        engine as unknown as { resendReliableMessagesForResume: (seq: number) => Promise<void> }
      ).resendReliableMessagesForResume(0);
      expect(dc.send).toHaveBeenCalledTimes(1);
      expect(buffer.getAll()[0].sent).toBe(true);
    });

    it('still rejects when the engine is closed while waiting', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      stubEngine(engine, dc);

      dc.bufferedAmount = 2 * 1024 * 1024;
      const send = engine.sendDataPacket(makePacket(1), DataChannelKind.RELIABLE);
      await tick();
      Object.assign(engine as unknown as Record<string, unknown>, { _isClosed: true });
      engineChannel(engine, 'reliableChannel').invalidateWaiters('engine closed');

      await expect(send).rejects.toBeInstanceOf(UnexpectedConnectionState);
      expect(dc.send).not.toHaveBeenCalled();
    });

    it('queues without waiting while a reconnect attempt is in progress', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      const buffer = stubEngine(engine, dc);
      Object.assign(engine as unknown as Record<string, unknown>, { attemptingReconnect: true });

      // Even with a full buffer, the send resolves immediately instead of parking.
      dc.bufferedAmount = 2 * 1024 * 1024;
      await expect(
        engine.sendDataPacket(makePacket(1), DataChannelKind.RELIABLE),
      ).resolves.toBeUndefined();
      expect(dc.send).not.toHaveBeenCalled();
      expect(buffer.length).toBe(1);
      expect(buffer.getAll()[0].sent).toBe(false);
    });
  });

  describe('sendDataTrackFrame', () => {
    it('ensures the publisher is connected before sending (direct data-track path)', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      // The channel only becomes available once the publisher connection has been established —
      // mirroring the lazily negotiated publisher case that Room's packetAvailable path hits.
      const ensurePublisherConnected = vi.fn(async () => {
        attachFakeChannel(engine, 'dataTrackChannel', dc);
      });
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: false,
        ensurePublisherConnected,
      });

      await engine.sendDataTrackFrame(new Uint8Array([1]));

      expect(ensurePublisherConnected).toHaveBeenCalledWith(DataChannelKind.DATA_TRACK_LOSSY);
      expect(dc.send).toHaveBeenCalledTimes(1);
    });

    it('keeps each channel’s byterate stat isolated from the other’s traffic', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: false,
        ensurePublisherConnected: vi.fn().mockResolvedValue(undefined),
      });
      attachFakeChannel(engine, 'lossyChannel', dc);
      attachFakeChannel(engine, 'dataTrackChannel', dc);
      const lossyStat = () =>
        (engine as unknown as { lossyChannel: { statCurrentBytes: number } }).lossyChannel
          .statCurrentBytes;

      // Data-track traffic (sendDataTrackFrame → data-track channel) must not move the LOSSY channel's
      // stat — it would inflate the lossy channel's dynamically tuned drop threshold with traffic
      // that channel never carries.
      await engine.sendDataTrackFrame(new Uint8Array(1000));
      expect(lossyStat()).toBe(0);

      // A plain lossy publishData packet goes through sendDataPacket → lossy channel.
      const lossyPacket = new DataPacket({
        kind: DataPacket_Kind.LOSSY,
        value: { case: 'user', value: new UserPacket({ payload: new Uint8Array(100) }) },
      });
      await engine.sendDataPacket(lossyPacket, DataChannelKind.LOSSY);
      expect(lossyStat()).toBeGreaterThan(0);
    });
  });

  describe('waitForBufferHeadroom', () => {
    it('rejects parked waiters and releases the lock when the data channels are invalidated', async () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const dc = new FakeDataChannel();
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: false,
      });
      attachFakeChannel(engine, 'reliableChannel', dc);

      // Park a waiter: buffer above the reliable high-water mark, holding the headroom lock.
      dc.bufferedAmount = 2 * 1024 * 1024;
      const parked = engine.waitForBufferHeadroom(DataChannelKind.RELIABLE);
      // Swallow the expected rejection so it can't surface as unhandled before we assert on it.
      parked.catch(() => {});
      await tick();

      // The channel object gets abandoned (e.g. createDataChannels on the Safari resume path).
      engineChannel(engine, 'reliableChannel').invalidateWaiters('data channels recreated');

      await expect(parked).rejects.toBeInstanceOf(UnexpectedConnectionState);

      // The lock must be free again: a wait against the fresh, drained channel resolves instead
      // of queueing forever behind the stranded waiter.
      dc.bufferedAmount = 0;
      await expect(engine.waitForBufferHeadroom(DataChannelKind.RELIABLE)).resolves.toBeUndefined();
    });
  });

  describe('handleDataChannelClose', () => {
    function stubCloseEnv(
      engine: RTCEngine,
      { closed, publisherState }: { closed: boolean; publisherState: RTCPeerConnectionState },
    ) {
      const error = vi.fn();
      Object.assign(engine as unknown as Record<string, unknown>, {
        _isClosed: closed,
        log: { error },
        pcManager: {
          publisher: { getConnectionState: () => publisherState },
        },
      });
      return error;
    }

    function fireClose(engine: RTCEngine, kind: DataChannelKind) {
      (
        engine as unknown as {
          handleDataChannelClose: (kind: DataChannelKind) => () => void;
        }
      ).handleDataChannelClose(kind)();
    }

    it('logs an error when a publisher channel closes while connected', () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const error = stubCloseEnv(engine, { closed: false, publisherState: 'connected' });

      fireClose(engine, DataChannelKind.RELIABLE);

      expect(error).toHaveBeenCalledOnce();
      expect(error.mock.calls[0][0]).toContain('RELIABLE');
    });

    it('stays quiet when the engine is already closed', () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const error = stubCloseEnv(engine, { closed: true, publisherState: 'connected' });

      fireClose(engine, DataChannelKind.RELIABLE);

      expect(error).not.toHaveBeenCalled();
    });

    it('stays quiet when the publisher PC is no longer connected', () => {
      const engine = new RTCEngine(roomOptionDefaults);
      const error = stubCloseEnv(engine, { closed: false, publisherState: 'closed' });

      fireClose(engine, DataChannelKind.RELIABLE);

      expect(error).not.toHaveBeenCalled();
    });
  });
});
